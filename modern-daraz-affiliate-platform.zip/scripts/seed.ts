import "dotenv/config";
import { db, pool } from "../src/db";
import { categories, deals, dealEvents, dealAlertSubscribers } from "../src/db/schema";
import { computePricing } from "../src/lib/pricing";
import { slugify } from "../src/lib/mutations";

const IMAGES = {
  earbuds: [
    "https://images.pexels.com/photos/3756985/pexels-photo-3756985.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/3394653/pexels-photo-3394653.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/3756912/pexels-photo-3756912.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  mobileAccessories: [
    "https://images.pexels.com/photos/7989741/pexels-photo-7989741.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/17984647/pexels-photo-17984647.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/12953565/pexels-photo-12953565.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/36680544/pexels-photo-36680544.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  fashion: [
    "https://images.pexels.com/photos/27113471/pexels-photo-27113471.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/14703446/pexels-photo-14703446.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/27113470/pexels-photo-27113470.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/19869759/pexels-photo-19869759.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  beauty: [
    "https://images.pexels.com/photos/3750640/pexels-photo-3750640.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/6527697/pexels-photo-6527697.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/6527699/pexels-photo-6527699.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/6527704/pexels-photo-6527704.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  home: [
    "https://images.pexels.com/photos/32541183/pexels-photo-32541183.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/20557088/pexels-photo-20557088.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/20557234/pexels-photo-20557234.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/33948970/pexels-photo-33948970.png?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  kitchen: [
    "https://images.pexels.com/photos/20557063/pexels-photo-20557063.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/29463558/pexels-photo-29463558.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/17210074/pexels-photo-17210074.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/5556176/pexels-photo-5556176.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  gadgets: [
    "https://images.pexels.com/photos/12564670/pexels-photo-12564670.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/12880803/pexels-photo-12880803.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/11677077/pexels-photo-11677077.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/31541678/pexels-photo-31541678.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  computer: [
    "https://images.pexels.com/photos/12877898/pexels-photo-12877898.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/4533076/pexels-photo-4533076.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/2659939/pexels-photo-2659939.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  sports: [
    "https://images.pexels.com/photos/32610335/pexels-photo-32610335.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/11433027/pexels-photo-11433027.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/31152187/pexels-photo-31152187.png?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/28455391/pexels-photo-28455391.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  kids: [
    "https://images.pexels.com/photos/16045136/pexels-photo-16045136.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/34686413/pexels-photo-34686413.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/14211426/pexels-photo-14211426.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  lifestyle: [
    "https://images.pexels.com/photos/5867971/pexels-photo-5867971.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/31453948/pexels-photo-31453948.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/5984424/pexels-photo-5984424.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/4452517/pexels-photo-4452517.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  electronics: [
    "https://images.pexels.com/photos/6958460/pexels-photo-6958460.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/16045125/pexels-photo-16045125.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/3394653/pexels-photo-3394653.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
  others: [
    "https://images.pexels.com/photos/3568521/pexels-photo-3568521.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/6634844/pexels-photo-6634844.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/29765807/pexels-photo-29765807.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ],
};

const CATEGORY_DEFS = [
  { name: "Electronics", slug: "electronics", icon: "Cpu", description: "TVs, speakers, cameras & more" },
  { name: "Mobile Accessories", slug: "mobile-accessories", icon: "Smartphone", description: "Cases, chargers, earbuds & cables" },
  { name: "Fashion", slug: "fashion", icon: "Shirt", description: "Clothing, shoes & accessories" },
  { name: "Beauty", slug: "beauty", icon: "Sparkles", description: "Skincare, makeup & personal care" },
  { name: "Home & Living", slug: "home-living", icon: "Home", description: "Decor, storage & furnishing" },
  { name: "Kitchen", slug: "kitchen", icon: "UtensilsCrossed", description: "Appliances & cookware" },
  { name: "Gadgets", slug: "gadgets", icon: "Watch", description: "Smartwatches & trending tech" },
  { name: "Computer & Accessories", slug: "computer-accessories", icon: "Laptop", description: "Laptops, mice, keyboards" },
  { name: "Lifestyle", slug: "lifestyle", icon: "Briefcase", description: "Bags, travel & everyday carry" },
  { name: "Sports", slug: "sports", icon: "Dumbbell", description: "Fitness & outdoor gear" },
  { name: "Kids", slug: "kids", icon: "Baby", description: "Toys & kids essentials" },
  { name: "Others", slug: "others", icon: "Package", description: "Everything else worth a deal" },
];

type SeedDeal = {
  name: string;
  category: string;
  brand: string;
  image: string;
  regular: number;
  sale: number;
  rating: number;
  reviews: number;
  flash?: boolean;
  featured?: boolean;
  hoursToEnd?: number;
  expired?: boolean;
  description: string;
};

function img(list: string[], idx: number) {
  return list[idx % list.length];
}

const SEED_DEALS: SeedDeal[] = [
  { name: "Xiaomi Redmi Buds 5 Wireless Earbuds", category: "mobile-accessories", brand: "Xiaomi", image: img(IMAGES.earbuds, 0), regular: 2999, sale: 1999, rating: 4.7, reviews: 2140, flash: true, featured: true, hoursToEnd: 5, description: "True wireless earbuds with active noise cancellation, 30-hour battery life, and crystal-clear call quality. Perfect for daily commute and workouts." },
  { name: "QCY T13 ANC Bluetooth Earbuds", category: "mobile-accessories", brand: "QCY", image: img(IMAGES.earbuds, 1), regular: 1800, sale: 990, rating: 4.5, reviews: 980, flash: true, hoursToEnd: 8, description: "Compact wireless earbuds with hybrid active noise cancellation and touch controls." },
  { name: "Premium Over-Ear Headphones with Mic", category: "mobile-accessories", brand: "Baseus", image: img(IMAGES.earbuds, 2), regular: 2500, sale: 1450, rating: 4.4, reviews: 540, description: "Comfortable over-ear design with deep bass and built-in microphone for calls." },
  { name: "Wireless Sports Earphones Sweatproof", category: "mobile-accessories", brand: "Haylou", image: img(IMAGES.earbuds, 3), regular: 1500, sale: 850, rating: 4.3, reviews: 712, featured: true, description: "IPX5 sweat-resistant earphones designed for intense workouts and running." },

  { name: "65W Fast Charging Power Bank 20000mAh", category: "mobile-accessories", brand: "Anker", image: img(IMAGES.mobileAccessories, 0), regular: 3500, sale: 2399, rating: 4.8, reviews: 1890, featured: true, description: "High-capacity power bank with 65W fast charging for laptops, phones, and tablets." },
  { name: "Shockproof Silicone Phone Case", category: "mobile-accessories", brand: "Generic", image: img(IMAGES.mobileAccessories, 1), regular: 450, sale: 199, rating: 4.2, reviews: 3200, description: "Durable shockproof case with raised edges to protect your screen and camera." },
  { name: "Tempered Glass Screen Protector (2-Pack)", category: "mobile-accessories", brand: "Generic", image: img(IMAGES.mobileAccessories, 2), regular: 350, sale: 149, rating: 4.1, reviews: 2750, description: "9H hardness tempered glass with anti-fingerprint coating, pack of 2." },
  { name: "Magnetic Car Phone Mount Holder", category: "mobile-accessories", brand: "Ugreen", image: img(IMAGES.mobileAccessories, 3), regular: 900, sale: 549, rating: 4.4, reviews: 610, description: "Strong magnetic mount for dashboard or air vent, compatible with all smartphones." },

  { name: "Men's Casual Sneakers Breathable", category: "fashion", brand: "Urban Style", image: img(IMAGES.fashion, 0), regular: 2200, sale: 1320, rating: 4.3, reviews: 860, featured: true, description: "Lightweight breathable sneakers with cushioned sole for all-day comfort." },
  { name: "Women's Summer Floral Dress", category: "fashion", brand: "ChicWear", image: img(IMAGES.fashion, 1), regular: 1800, sale: 999, rating: 4.5, reviews: 430, description: "Flowy floral dress made from breathable cotton blend, perfect for summer." },
  { name: "Unisex Running Shoes Lightweight", category: "fashion", brand: "SprintX", image: img(IMAGES.fashion, 2), regular: 3200, sale: 1890, rating: 4.6, reviews: 1120, flash: true, hoursToEnd: 12, description: "Engineered mesh upper with responsive cushioning for daily runs." },
  { name: "Classic Leather Wallet for Men", category: "fashion", brand: "LeatherCraft", image: img(IMAGES.fashion, 3), regular: 1200, sale: 690, rating: 4.4, reviews: 390, description: "Genuine leather bi-fold wallet with RFID-blocking card slots." },

  { name: "Matte Lipstick Set (6 Shades)", category: "beauty", brand: "GlamLook", image: img(IMAGES.beauty, 0), regular: 1500, sale: 799, rating: 4.5, reviews: 1340, featured: true, description: "Long-lasting matte lipstick set with rich pigmentation in 6 trending shades." },
  { name: "Vitamin C Brightening Serum 30ml", category: "beauty", brand: "SkinPure", image: img(IMAGES.beauty, 1), regular: 1200, sale: 699, rating: 4.6, reviews: 980, description: "Brightening serum with 20% Vitamin C to reduce dark spots and even skin tone." },
  { name: "Professional Makeup Brush Set (12pcs)", category: "beauty", brand: "GlamLook", image: img(IMAGES.beauty, 2), regular: 1600, sale: 850, rating: 4.3, reviews: 560, description: "Soft synthetic bristle brushes for flawless foundation, blush, and eye makeup." },
  { name: "Hydrating Face Sheet Mask (10-Pack)", category: "beauty", brand: "SkinPure", image: img(IMAGES.beauty, 3), regular: 800, sale: 420, rating: 4.4, reviews: 1430, description: "Deeply hydrating sheet masks infused with hyaluronic acid and aloe vera." },

  { name: "Minimalist LED Table Lamp", category: "home-living", brand: "HomeGlow", image: img(IMAGES.home, 0), regular: 1900, sale: 1150, rating: 4.3, reviews: 320, description: "Touch-dimmable LED lamp with 3 color temperatures, perfect for bedside or desk." },
  { name: "Decorative Wall Art Canvas Set (3pcs)", category: "home-living", brand: "ArtSpace", image: img(IMAGES.home, 1), regular: 2500, sale: 1399, rating: 4.2, reviews: 210, description: "Modern abstract canvas prints to instantly upgrade your living room decor." },
  { name: "Soft Plush Throw Blanket", category: "home-living", brand: "CozyHome", image: img(IMAGES.home, 2), regular: 1400, sale: 820, rating: 4.5, reviews: 480, description: "Ultra-soft microfiber throw blanket, machine washable and lightweight." },
  { name: "Scandinavian Style Accent Chair Cushion", category: "home-living", brand: "HomeGlow", image: img(IMAGES.home, 3), regular: 1100, sale: 640, rating: 4.1, reviews: 150, description: "Comfortable foam-filled cushion with removable washable cover." },

  { name: "Multi-Function Electric Blender 1.5L", category: "kitchen", brand: "Miyako", image: img(IMAGES.kitchen, 0), regular: 3200, sale: 1990, rating: 4.6, reviews: 740, featured: true, description: "Powerful 600W motor with 4-speed settings for smoothies, juices, and more." },
  { name: "Stainless Steel Knife Set (6pcs)", category: "kitchen", brand: "ChefPro", image: img(IMAGES.kitchen, 1), regular: 2100, sale: 1250, rating: 4.4, reviews: 390, description: "Precision-forged stainless steel knives with ergonomic non-slip handles." },
  { name: "2-Slice Automatic Pop-up Toaster", category: "kitchen", brand: "Miyako", image: img(IMAGES.kitchen, 2), regular: 2800, sale: 1799, rating: 4.3, reviews: 260, description: "7 browning levels with removable crumb tray for easy cleaning." },
  { name: "Non-Stick Cookware Set (5pcs)", category: "kitchen", brand: "ChefPro", image: img(IMAGES.kitchen, 3), regular: 4500, sale: 2990, rating: 4.5, reviews: 310, description: "Durable non-stick coating, compatible with gas and induction stoves." },

  { name: "Smartwatch with Heart Rate Monitor", category: "gadgets", brand: "Amazfit", image: img(IMAGES.gadgets, 0), regular: 5500, sale: 3299, rating: 4.6, reviews: 1670, featured: true, flash: true, hoursToEnd: 20, description: "AMOLED display smartwatch with heart rate, SpO2 monitoring, and 14-day battery." },
  { name: "Mini Portable Projector 1080p", category: "gadgets", brand: "TechVision", image: img(IMAGES.gadgets, 1), regular: 8500, sale: 5490, rating: 4.2, reviews: 220, description: "Compact home projector supporting full HD content with built-in speaker." },
  { name: "Fitness Band with Sleep Tracking", category: "gadgets", brand: "Amazfit", image: img(IMAGES.gadgets, 2), regular: 2200, sale: 1290, rating: 4.3, reviews: 540, description: "Lightweight fitness tracker with step counter, sleep tracking, and notifications." },
  { name: "Smart LED Strip Lights 5m RGB", category: "gadgets", brand: "Govee", image: img(IMAGES.gadgets, 3), regular: 1600, sale: 899, rating: 4.5, reviews: 980, description: "App-controlled RGB LED strip with music sync and voice assistant support." },

  { name: "Wireless Gaming Mouse RGB", category: "computer-accessories", brand: "Logitech", image: img(IMAGES.computer, 0), regular: 2800, sale: 1799, rating: 4.7, reviews: 890, featured: true, description: "High-precision sensor with customizable RGB lighting and programmable buttons." },
  { name: "Mechanical Gaming Keyboard Backlit", category: "computer-accessories", brand: "Redragon", image: img(IMAGES.computer, 1), regular: 3500, sale: 2190, rating: 4.5, reviews: 640, description: "Durable mechanical switches with per-key RGB backlighting." },
  { name: "15.6-inch Laptop Sleeve Bag", category: "computer-accessories", brand: "Ugreen", image: img(IMAGES.computer, 2), regular: 1300, sale: 790, rating: 4.3, reviews: 300, description: "Water-resistant padded sleeve to protect your laptop on the go." },

  { name: "Adjustable Dumbbell Set 20kg", category: "sports", brand: "FitPro", image: img(IMAGES.sports, 0), regular: 4200, sale: 2890, rating: 4.4, reviews: 210, description: "Space-saving adjustable dumbbells for home strength training." },
  { name: "Yoga Mat Non-Slip 6mm", category: "sports", brand: "FitPro", image: img(IMAGES.sports, 1), regular: 1200, sale: 650, rating: 4.6, reviews: 760, description: "Extra thick non-slip yoga mat with carry strap included." },
  { name: "Resistance Bands Set (5 Levels)", category: "sports", brand: "FlexFit", image: img(IMAGES.sports, 2), regular: 900, sale: 450, rating: 4.3, reviews: 540, description: "Full-body resistance training bands for home workouts, 5 resistance levels." },
  { name: "Men's Compression Running T-Shirt", category: "sports", brand: "SprintX", image: img(IMAGES.sports, 3), regular: 1100, sale: 599, rating: 4.2, reviews: 180, description: "Moisture-wicking compression fit shirt for high-intensity training." },

  { name: "Educational Building Blocks Set (200pcs)", category: "kids", brand: "KidJoy", image: img(IMAGES.kids, 0), regular: 1800, sale: 990, rating: 4.7, reviews: 420, featured: true, description: "STEM-inspired building blocks to boost creativity and motor skills." },
  { name: "Remote Control Stunt Car", category: "kids", brand: "KidJoy", image: img(IMAGES.kids, 1), regular: 2500, sale: 1399, rating: 4.4, reviews: 310, flash: true, hoursToEnd: 30, description: "360-degree stunt RC car with rechargeable battery, ages 6+." },
  { name: "Kids Interactive Learning Tablet", category: "kids", brand: "SmartTots", image: img(IMAGES.kids, 2), regular: 3200, sale: 1990, rating: 4.3, reviews: 260, description: "Pre-loaded educational games and activities for toddlers." },

  { name: "Anti-Theft Travel Backpack 35L", category: "lifestyle", brand: "UrbanPack", image: img(IMAGES.lifestyle, 0), regular: 3200, sale: 1990, rating: 4.6, reviews: 720, featured: true, description: "USB charging port, anti-theft zippers, and padded laptop compartment." },
  { name: "Leather Crossbody Sling Bag", category: "lifestyle", brand: "LeatherCraft", image: img(IMAGES.lifestyle, 1), regular: 1900, sale: 1150, rating: 4.3, reviews: 310, description: "Compact sling bag made from genuine leather, perfect for daily essentials." },
  { name: "Polarized Sunglasses UV400", category: "lifestyle", brand: "SunShade", image: img(IMAGES.lifestyle, 2), regular: 1200, sale: 650, rating: 4.4, reviews: 480, description: "Scratch-resistant polarized lenses with 100% UV protection." },
  { name: "Travel Organizer Pouch Set (4pcs)", category: "lifestyle", brand: "UrbanPack", image: img(IMAGES.lifestyle, 3), regular: 850, sale: 430, rating: 4.2, reviews: 190, description: "Compression packing cubes to organize your luggage efficiently." },

  { name: "Portable Bluetooth Speaker Waterproof", category: "electronics", brand: "JBL", image: img(IMAGES.electronics, 0), regular: 4500, sale: 2990, rating: 4.7, reviews: 1340, featured: true, flash: true, hoursToEnd: 15, description: "IPX7 waterproof speaker with 12-hour battery and deep bass." },
  { name: "Instant Mini Photo Printer Camera", category: "electronics", brand: "Fujifilm", image: img(IMAGES.electronics, 1), regular: 7500, sale: 5490, rating: 4.5, reviews: 390, description: "Compact instant camera that prints credit-card sized photos instantly." },
  { name: "Noise Cancelling Wired Headset", category: "electronics", brand: "Sony", image: img(IMAGES.electronics, 2), regular: 2600, sale: 1590, rating: 4.4, reviews: 260, description: "Comfortable over-ear wired headset ideal for calls and media." },

  { name: "Daily Essentials Organizer Tray", category: "others", brand: "Generic", image: img(IMAGES.others, 0), regular: 650, sale: 299, rating: 4.1, reviews: 140, description: "Multi-purpose desktop organizer tray for stationery and accessories." },
  { name: "Reusable Silicone Food Storage Bags (5pcs)", category: "others", brand: "EcoKitchen", image: img(IMAGES.others, 1), regular: 900, sale: 480, rating: 4.3, reviews: 220, description: "Leak-proof reusable silicone bags, dishwasher and freezer safe." },
  { name: "Aromatherapy Essential Oil Diffuser", category: "others", brand: "ZenHome", image: img(IMAGES.others, 2), regular: 1500, sale: 820, rating: 4.4, reviews: 310, description: "Ultrasonic diffuser with 7-color LED and auto shut-off safety feature." },

  { name: "Old Model Basic Feature Phone", category: "mobile-accessories", brand: "Generic", image: img(IMAGES.mobileAccessories, 1), regular: 1500, sale: 1500, rating: 3.9, reviews: 90, description: "Simple and reliable feature phone — currently at regular Daraz price, no active discount." },
  { name: "Clearance Winter Jacket (Last Season)", category: "fashion", brand: "Urban Style", image: img(IMAGES.fashion, 3), regular: 2200, sale: 1100, rating: 4.0, reviews: 60, expired: true, description: "Warm winter jacket, previous season clearance. This promotional deal has ended." },
];

async function main() {
  console.log("Seeding database...");

  await db.delete(dealEvents);
  await db.delete(deals);
  await db.delete(categories);
  await db.delete(dealAlertSubscribers);

  const categoryIdBySlug = new Map<string, number>();
  for (const cat of CATEGORY_DEFS) {
    const [row] = await db.insert(categories).values(cat).returning();
    categoryIdBySlug.set(cat.slug, row.id);
  }

  const now = Date.now();

  for (const item of SEED_DEALS) {
    const categoryId = categoryIdBySlug.get(item.category);
    if (!categoryId) continue;

    const pricing = computePricing({ regularPrice: item.regular, salePrice: item.sale });
    const slug = slugify(item.name);

    let dealEnd: Date | null = null;
    let status: "active" | "expired" | "draft" = "active";

    if (item.expired) {
      status = "expired";
      dealEnd = new Date(now - 1000 * 60 * 60 * 24);
    } else if (item.hoursToEnd) {
      dealEnd = new Date(now + item.hoursToEnd * 60 * 60 * 1000);
    }

    const [row] = await db
      .insert(deals)
      .values({
        productName: item.name,
        slug,
        productImage: item.image,
        categoryId,
        brand: item.brand,
        regularPrice: item.regular.toString(),
        salePrice: item.sale.toString(),
        discountPercentage: pricing.discountPercentage.toString(),
        savingsAmount: pricing.savingsAmount.toString(),
        rating: item.rating.toString(),
        reviewCount: item.reviews,
        affiliateUrl: `https://www.daraz.com.bd/products/${slug}-i000000000-s0000000000.html?spm=a2a0e.dealbazi.placeholder`,
        description: item.description,
        dealStart: new Date(now - 1000 * 60 * 60 * 24 * 2),
        dealEnd,
        status,
        featured: Boolean(item.featured),
        isFlashDeal: Boolean(item.flash),
        viewCount: Math.floor(Math.random() * 900) + 50,
        clickCount: Math.floor(Math.random() * 120) + 5,
      })
      .returning();

    console.log(`Inserted: ${row.productName}`);
  }

  console.log("Seeding complete.");
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
