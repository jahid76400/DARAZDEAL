import {
  boolean,
  index,
  integer,
  numeric,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const dealStatusEnum = pgEnum("deal_status", [
  "active",
  "expired",
  "draft",
]);

export const eventTypeEnum = pgEnum("event_type", ["view", "click"]);

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  icon: varchar("icon", { length: 60 }).notNull().default("Sparkles"),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const deals = pgTable(
  "deals",
  {
    id: serial("id").primaryKey(),
    productName: varchar("product_name", { length: 255 }).notNull(),
    slug: varchar("slug", { length: 255 }).notNull().unique(),
    productImage: text("product_image").notNull(),
    categoryId: integer("category_id")
      .notNull()
      .references(() => categories.id, { onDelete: "set null" }),
    brand: varchar("brand", { length: 120 }).notNull().default("Generic"),
    regularPrice: numeric("regular_price", { precision: 12, scale: 2 }).notNull(),
    salePrice: numeric("sale_price", { precision: 12, scale: 2 }).notNull(),
    discountPercentage: numeric("discount_percentage", { precision: 5, scale: 2 })
      .notNull()
      .default("0"),
    savingsAmount: numeric("savings_amount", { precision: 12, scale: 2 })
      .notNull()
      .default("0"),
    rating: numeric("rating", { precision: 2, scale: 1 }).notNull().default("4.5"),
    reviewCount: integer("review_count").notNull().default(0),
    affiliateUrl: text("affiliate_url").notNull(),
    description: text("description").notNull().default(""),
    dealStart: timestamp("deal_start").notNull().defaultNow(),
    dealEnd: timestamp("deal_end"),
    status: dealStatusEnum("status").notNull().default("active"),
    featured: boolean("featured").notNull().default(false),
    isFlashDeal: boolean("is_flash_deal").notNull().default(false),
    viewCount: integer("view_count").notNull().default(0),
    clickCount: integer("click_count").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => [
    index("deals_category_idx").on(table.categoryId),
    index("deals_status_idx").on(table.status),
    index("deals_featured_idx").on(table.featured),
  ],
);

export const dealAlertSubscribers = pgTable("deal_alert_subscribers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  channel: varchar("channel", { length: 40 }).notNull().default("email"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const dealEvents = pgTable(
  "deal_events",
  {
    id: serial("id").primaryKey(),
    dealId: integer("deal_id")
      .notNull()
      .references(() => deals.id, { onDelete: "cascade" }),
    type: eventTypeEnum("type").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => [
    index("deal_events_deal_idx").on(table.dealId),
    index("deal_events_type_idx").on(table.type),
    index("deal_events_created_idx").on(table.createdAt),
  ],
);
