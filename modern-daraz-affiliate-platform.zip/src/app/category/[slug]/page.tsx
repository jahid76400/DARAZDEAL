import { notFound } from "next/navigation";
import type { Metadata } from "next";
import * as Icons from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { getCategories, getCategoryBySlug, listDeals } from "@/lib/data";
import { parseDealFilters, type RawSearchParams } from "@/lib/searchParams";
import DealsListingLayout from "@/components/deals/DealsListingLayout";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const category = await getCategoryBySlug(slug);
  if (!category) return { title: "Category not found" };
  return {
    title: `${category.name} Deals`,
    description: `Browse the best Daraz ${category.name} deals with verified discounts and real savings.`,
    alternates: { canonical: `/category/${category.slug}` },
  };
}

export default async function CategoryPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<RawSearchParams>;
}) {
  const { slug } = await params;
  const rawParams = await searchParams;
  const category = await getCategoryBySlug(slug);
  if (!category) notFound();

  const filters = parseDealFilters(rawParams);
  const [deals, allCategories] = await Promise.all([
    listDeals({ ...filters, category: slug }),
    getCategories(),
  ]);

  const Icon = (Icons as unknown as Record<string, LucideIcon>)[category.icon] ?? Icons.Sparkles;

  return (
    <DealsListingLayout
      title={category.name}
      subtitle={category.description ?? `Best Daraz deals in ${category.name}`}
      icon={
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft text-brand dark:bg-brand/15">
          <Icon size={22} />
        </span>
      }
      deals={deals}
      categories={allCategories}
      hideCategoryFilter
      breadcrumbs={[{ label: "Home", href: "/" }, { label: category.name }]}
    />
  );
}
