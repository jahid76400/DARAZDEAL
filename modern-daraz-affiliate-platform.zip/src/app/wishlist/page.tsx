"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Heart, History } from "lucide-react";
import DealGrid from "@/components/deals/DealGrid";
import { useRecentlyViewed, useWishlist } from "@/lib/hooks/useWishlist";
import type { Deal } from "@/lib/types";

export default function WishlistPage() {
  const { wishlist, hydrated: wishlistHydrated } = useWishlist();
  const { recentlyViewed, hydrated: recentHydrated } = useRecentlyViewed();
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);

  const ids = [...new Set([...wishlist, ...recentlyViewed])];

  useEffect(() => {
    if (!wishlistHydrated || !recentHydrated) return;
    if (ids.length === 0) {
      setDeals([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    fetch(`/api/deals/by-ids?ids=${ids.join(",")}`)
      .then((res) => res.json())
      .then((data) => setDeals(data.deals ?? []))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wishlistHydrated, recentHydrated, ids.join(",")]);

  const wishlistDeals = deals.filter((d) => wishlist.includes(d.id));
  const recentDeals = deals
    .filter((d) => recentlyViewed.includes(d.id))
    .sort((a, b) => recentlyViewed.indexOf(a.id) - recentlyViewed.indexOf(b.id));

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft text-brand dark:bg-brand/15">
          <Heart size={22} />
        </span>
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">My Wishlist</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Saved locally on this device</p>
        </div>
      </div>

      <section className="mt-8">
        {!loading && wishlistDeals.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white/60 px-6 py-14 text-center dark:border-slate-700 dark:bg-slate-900/40">
            <p className="text-3xl">💔</p>
            <p className="mt-3 text-sm font-medium text-slate-500 dark:text-slate-400">
              You haven&apos;t saved any deals yet. Tap the heart icon on a deal to save it here.
            </p>
            <Link href="/deals/today" className="mt-4 inline-block rounded-full bg-brand px-5 py-2.5 text-sm font-bold text-white">
              Browse deals
            </Link>
          </div>
        ) : (
          <DealGrid deals={wishlistDeals} />
        )}
      </section>

      {recentDeals.length > 0 && (
        <section className="mt-14">
          <div className="mb-5 flex items-center gap-2">
            <History size={18} className="text-slate-400" />
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Recently Viewed</h2>
          </div>
          <DealGrid deals={recentDeals} />
        </section>
      )}
    </main>
  );
}
