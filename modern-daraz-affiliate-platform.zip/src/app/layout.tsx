import type { Metadata } from "next";
import { Poppins, Inter } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileBottomNav from "@/components/layout/MobileBottomNav";
import { getCategories } from "@/lib/data";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
  variable: "--font-display",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "DealBazi — Best Daraz Deals & Offers in Bangladesh",
    template: "%s | DealBazi",
  },
  description:
    "Discover today's biggest Daraz discounts, compare original vs sale prices, and see exactly how much you save before you buy.",
  metadataBase: new URL("https://dealbazi.example.com"),
  openGraph: {
    title: "DealBazi — Best Daraz Deals & Offers",
    description:
      "Discover today's biggest Daraz discounts and see exactly how much you save, curated daily.",
    type: "website",
    siteName: "DealBazi",
  },
  robots: { index: true, follow: true },
};

const THEME_SCRIPT = `
(function() {
  try {
    var stored = localStorage.getItem('dealbazi-theme');
    var theme = stored || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    if (theme === 'dark') document.documentElement.classList.add('dark');
  } catch (e) {}
})();
`;

export default async function RootLayout({ children }: { children: ReactNode }) {
  const categories = await getCategories();

  return (
    <html lang="en" className={`${poppins.variable} ${inter.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_SCRIPT }} />
      </head>
      <body className="min-h-screen bg-[#f7f7fb] font-[family-name:var(--font-sans)] text-slate-900 antialiased transition-colors duration-300 dark:bg-[#0b0d14] dark:text-slate-100">
        <Header categories={categories} />
        <div className="pb-16 md:pb-0">{children}</div>
        <Footer categories={categories} />
        <MobileBottomNav />
      </body>
    </html>
  );
}
