import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Star, ShieldCheck, Clock, Tag } from "lucide-react";
import type { Metadata } from "next";
import { getDealBySlug, listDeals, recordDealEvent } from "@/lib/data";
import { formatBDT } from "@/lib/format";
import Breadcrumbs from "@/components/deals/Breadcrumbs";
import WishlistButton from "@/components/deals/WishlistButton";
import ShareButton from "@/components/deals/ShareButton";
import ViewDealButton from "@/components/deals/ViewDealButton";
import DealGrid from "@/components/deals/DealGrid";
import RecentlyViewedTracker from "@/components/deals/RecentlyViewedTracker";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const deal = await getDealBySlug(slug);
  if (!deal) return { title: "Deal not found" };

  const description = `${deal.productName} — Regular price ${formatBDT(deal.regularPrice)}, now ${formatBDT(deal.salePrice)}. Save ${formatBDT(deal.savingsAmount)} (${deal.discountPercentage}% off) on Daraz.`;

  return {
    title: deal.productName,
    description,
    openGraph: {
      title: `${deal.productName} — ${deal.discountPercentage}% OFF`,
      description,
      images: [{ url: deal.productImage }],
      type: "website",
    },
    alternates: { canonical: `/deal/${deal.slug}` },
  };
}

export default async function DealPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const deal = await getDealBySlug(slug);
  if (!deal) notFound();

  await recordDealEvent(deal.id, "view");

  const related = (await listDeals({ category: deal.categorySlug, limit: 6 })).filter((d) => d.id !== deal.id);

  const productJsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: deal.productName,
    image: [deal.productImage],
    description: deal.description,
    brand: { "@type": "Brand", name: deal.brand },
    aggregateRating: deal.reviewCount > 0 ? {
      "@type": "AggregateRating",
      ratingValue: deal.rating,
      reviewCount: deal.reviewCount,
    } : undefined,
    offers: {
      "@type": "Offer",
      priceCurrency: "BDT",
      price: deal.salePrice,
      availability: deal.isExpired ? "https://schema.org/OutOfStock" : "https://schema.org/InStock",
      url: deal.affiliateUrl,
    },
  };

  return (
    <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
      <RecentlyViewedTracker dealId={deal.id} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productJsonLd) }} />

      <Breadcrumbs
        items={[
          { label: "Home", href: "/" },
          { label: deal.categoryName, href: `/category/${deal.categorySlug}` },
          { label: deal.productName },
        ]}
      />

      <div className="mt-5 grid gap-8 lg:grid-cols-2">
        <div className="relative aspect-square overflow-hidden rounded-3xl bg-slate-100 dark:bg-slate-800">
          <Image src={deal.productImage} alt={deal.productName} fill priority sizes="(max-width: 1024px) 100vw, 50vw" className="object-cover" />
          {deal.discountPercentage > 0 && !deal.isExpired && (
            <span className="absolute left-4 top-4 rounded-full bg-brand px-3 py-1.5 text-sm font-bold text-white shadow-lg">
              🔥 {deal.discountPercentage}% OFF
            </span>
          )}
          {deal.isExpired && (
            <span className="absolute left-4 top-4 rounded-full bg-slate-800/90 px-3 py-1.5 text-sm font-bold text-white">
              Deal Expired
            </span>
          )}
          <div className="absolute right-4 top-4">
            <WishlistButton dealId={deal.id} size="lg" />
          </div>
        </div>

        <div className="flex flex-col">
          <p className="text-xs font-bold uppercase tracking-wide text-brand">{deal.categoryName}</p>
          <h1 className="mt-1.5 text-2xl font-extrabold leading-tight text-slate-900 sm:text-3xl dark:text-white">
            {deal.productName}
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Brand: <span className="font-semibold text-slate-700 dark:text-slate-300">{deal.brand}</span></p>

          <div className="mt-3 flex items-center gap-2 text-sm">
            <span className="flex items-center gap-1 font-semibold text-slate-800 dark:text-slate-200">
              <Star size={16} className="fill-amber-400 text-amber-400" /> {deal.rating.toFixed(1)}
            </span>
            <span className="text-slate-400">· {deal.reviewCount.toLocaleString()} reviews</span>
          </div>

          <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50 p-5 dark:border-white/10 dark:bg-slate-900">
            <div className="flex flex-wrap items-end gap-3">
              <span className="text-3xl font-extrabold text-slate-900 dark:text-white">{formatBDT(deal.salePrice)}</span>
              {deal.discountPercentage > 0 && (
                <span className="text-base font-medium text-slate-400 line-through">{formatBDT(deal.regularPrice)}</span>
              )}
            </div>
            {deal.savingsAmount > 0 ? (
              <p className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-3 py-1 text-sm font-bold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400">
                🟢 You save {formatBDT(deal.savingsAmount)} ({deal.discountPercentage}% off)
              </p>
            ) : (
              <p className="mt-2 text-sm font-medium text-slate-500">Regular Daraz price — no discount applied right now.</p>
            )}

            <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1.5">
                <Clock size={13} />
                {deal.isExpired ? "Deal has expired" : deal.dealEnd ? `Ends ${new Date(deal.dealEnd).toLocaleString()}` : "Ongoing deal"}
              </span>
              <span className="flex items-center gap-1.5">
                <Tag size={13} /> Status: <span className="font-semibold capitalize">{deal.status}</span>
              </span>
            </div>

            <ViewDealButton
              deal={deal}
              label="🔥 GET THIS DEAL ON DARAZ →"
              className="mt-5 w-full justify-center rounded-2xl py-4 text-base shadow-lg shadow-brand/30"
            />
            <div className="mt-3 flex items-center justify-center gap-3">
              <ShareButton title={deal.productName} />
            </div>
          </div>

          <div className="mt-6">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">Product Description</h2>
            <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-slate-600 dark:text-slate-400">
              {deal.description || "No additional description provided for this deal yet."}
            </p>
          </div>

          <div className="mt-6 flex items-start gap-2.5 rounded-2xl bg-amber-50 p-4 text-xs leading-relaxed text-amber-800 dark:bg-amber-500/10 dark:text-amber-300">
            <ShieldCheck size={16} className="mt-0.5 shrink-0" />
            <p>
              Prices and availability may change on Daraz. Please verify the final price before purchasing.
              DealBazi shows real price comparisons only — we never display fake discounts.
            </p>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-14">
          <h2 className="mb-5 text-xl font-extrabold text-slate-900 dark:text-white">More in {deal.categoryName}</h2>
          <DealGrid deals={related} />
        </section>
      )}
    </main>
  );
}
