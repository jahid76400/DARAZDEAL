import type { MetadataRoute } from "next";
import { getCategories, listDeals } from "@/lib/data";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = "https://dealbazi.example.com";
  const [deals, categories] = await Promise.all([listDeals({ includeExpired: true }), getCategories()]);

  const staticRoutes = [
    "",
    "/deals/today",
    "/deals/flash",
    "/deals/biggest-discounts",
    "/deals/under/500",
    "/deals/under/1000",
    "/deals/under/2000",
    "/deals/under/5000",
    "/search",
    "/wishlist",
  ].map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date(),
  }));

  const categoryRoutes = categories.map((cat) => ({
    url: `${base}/category/${cat.slug}`,
    lastModified: new Date(),
  }));

  const dealRoutes = deals.map((deal) => ({
    url: `${base}/deal/${deal.slug}`,
    lastModified: new Date(deal.updatedAt),
  }));

  return [...staticRoutes, ...categoryRoutes, ...dealRoutes];
}
