import type { Metadata } from "next";
import { Zap } from "lucide-react";
import { getCategories, listDeals } from "@/lib/data";
import { parseDealFilters, type RawSearchParams } from "@/lib/searchParams";
import DealsListingLayout from "@/components/deals/DealsListingLayout";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Flash Deals",
  description: "Limited-time Daraz flash deals with countdown timers. Grab them before they're gone.",
  alternates: { canonical: "/deals/flash" },
};

export default async function FlashDealsPage({ searchParams }: { searchParams: Promise<RawSearchParams> }) {
  const rawParams = await searchParams;
  const filters = parseDealFilters(rawParams);
  const [deals, categories] = await Promise.all([
    listDeals({ ...filters, flashOnly: true, includeExpired: true }),
    getCategories(),
  ]);

  return (
    <DealsListingLayout
      title="⚡ Flash Deals"
      subtitle="Limited-time offers — grab them before the countdown ends"
      icon={
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-100 text-amber-600 dark:bg-amber-500/10">
          <Zap size={22} />
        </span>
      }
      deals={deals}
      categories={categories}
      breadcrumbs={[{ label: "Home", href: "/" }, { label: "Flash Deals" }]}
    />
  );
}
