import type { Metadata } from "next";
import { Calendar } from "lucide-react";
import { getCategories, listDeals } from "@/lib/data";
import { parseDealFilters, type RawSearchParams } from "@/lib/searchParams";
import DealsListingLayout from "@/components/deals/DealsListingLayout";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Today's Deals",
  description: "Hand-picked Daraz deals refreshed every day with verified discounts and real savings.",
  alternates: { canonical: "/deals/today" },
};

export default async function TodayDealsPage({ searchParams }: { searchParams: Promise<RawSearchParams> }) {
  const rawParams = await searchParams;
  const filters = parseDealFilters(rawParams);
  const [deals, categories] = await Promise.all([listDeals(filters), getCategories()]);

  return (
    <DealsListingLayout
      title="Today's Best Deals"
      subtitle="Hand-picked discounts refreshed every day"
      icon={
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft text-brand dark:bg-brand/15">
          <Calendar size={22} />
        </span>
      }
      deals={deals}
      categories={categories}
      breadcrumbs={[{ label: "Home", href: "/" }, { label: "Today's Deals" }]}
    />
  );
}
