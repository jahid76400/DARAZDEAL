import type { Metadata } from "next";
import { TrendingDown } from "lucide-react";
import { getCategories, listDeals } from "@/lib/data";
import { parseDealFilters, type RawSearchParams } from "@/lib/searchParams";
import DealsListingLayout from "@/components/deals/DealsListingLayout";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Biggest Discounts",
  description: "The highest discount percentage Daraz deals, automatically sorted from biggest to smallest.",
  alternates: { canonical: "/deals/biggest-discounts" },
};

export default async function BiggestDiscountsPage({ searchParams }: { searchParams: Promise<RawSearchParams> }) {
  const rawParams = await searchParams;
  const filters = parseDealFilters(rawParams);
  const [deals, categories] = await Promise.all([
    listDeals({ ...filters, sort: filters.sort ?? "discount", minDiscount: filters.minDiscount ?? 20 }),
    getCategories(),
  ]);

  return (
    <DealsListingLayout
      title="💰 Biggest Discounts"
      subtitle="Automatically sorted by the highest discount percentage"
      icon={
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600 dark:bg-emerald-500/10">
          <TrendingDown size={22} />
        </span>
      }
      deals={deals}
      categories={categories}
      breadcrumbs={[{ label: "Home", href: "/" }, { label: "Biggest Discounts" }]}
    />
  );
}
