import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Wallet } from "lucide-react";
import { getCategories, listDeals } from "@/lib/data";
import { parseDealFilters, type RawSearchParams } from "@/lib/searchParams";
import { formatBDT } from "@/lib/format";
import DealsListingLayout from "@/components/deals/DealsListingLayout";

export const dynamic = "force-dynamic";

const ALLOWED_AMOUNTS = [500, 1000, 2000, 5000];

export async function generateMetadata({ params }: { params: Promise<{ amount: string }> }): Promise<Metadata> {
  const { amount } = await params;
  return {
    title: `Deals Under ৳${amount}`,
    description: `Best Daraz deals under ৳${amount} — affordable products with verified discounts.`,
    alternates: { canonical: `/deals/under/${amount}` },
  };
}

export default async function UnderPricePage({
  params,
  searchParams,
}: {
  params: Promise<{ amount: string }>;
  searchParams: Promise<RawSearchParams>;
}) {
  const { amount } = await params;
  const numericAmount = Number(amount);
  if (!ALLOWED_AMOUNTS.includes(numericAmount)) notFound();

  const rawParams = await searchParams;
  const filters = parseDealFilters(rawParams);
  const [deals, categories] = await Promise.all([
    listDeals({ ...filters, maxPrice: numericAmount }),
    getCategories(),
  ]);

  return (
    <DealsListingLayout
      title={`Best Deals Under ${formatBDT(numericAmount)}`}
      subtitle="Affordable products that still pack great value"
      icon={
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-sky-100 text-sky-600 dark:bg-sky-500/10">
          <Wallet size={22} />
        </span>
      }
      deals={deals}
      categories={categories}
      breadcrumbs={[{ label: "Home", href: "/" }, { label: "Deals" }, { label: `Under ${formatBDT(numericAmount)}` }]}
    />
  );
}
