import Link from "next/link";
import { ArrowRight, TrendingDown, Wallet } from "lucide-react";
import Hero from "@/components/home/Hero";
import DealGrid from "@/components/deals/DealGrid";
import CategoryCard from "@/components/categories/CategoryCard";
import FlashDealsSection from "@/components/deals/FlashDealsSection";
import { getCategories, getCategoryDealCounts, listDeals } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [todaysDeals, flashDeals, biggestDiscounts, under500, categories, categoryCounts] = await Promise.all([
    listDeals({ sort: "newest", limit: 10 }),
    listDeals({ flashOnly: true, limit: 8 }),
    listDeals({ sort: "discount", minDiscount: 40, limit: 10 }),
    listDeals({ maxPrice: 500, limit: 10 }),
    getCategories(),
    getCategoryDealCounts(),
  ]);

  const flashEndTime =
    flashDeals.filter((d) => d.dealEnd).sort((a, b) => new Date(a.dealEnd!).getTime() - new Date(b.dealEnd!).getTime())[0]
      ?.dealEnd ?? new Date(Date.now() + 3 * 60 * 60 * 1000).toISOString();

  return (
    <main>
      <Hero />

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-xl font-extrabold text-slate-900 sm:text-2xl dark:text-white">Shop by Category</h2>
        </div>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-12">
          {categories.map((cat) => (
            <CategoryCard key={cat.slug} category={cat} count={categoryCounts[cat.slug] ?? 0} />
          ))}
        </div>
      </section>

      {/* Today's Best Deals */}
      <section className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 sm:text-2xl dark:text-white">🔥 Today&apos;s Best Deals</h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Hand-picked discounts refreshed every day</p>
          </div>
          <Link href="/deals/today" className="hidden items-center gap-1 text-sm font-semibold text-brand hover:underline sm:flex">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        <DealGrid deals={todaysDeals} />
        <div className="mt-5 text-center sm:hidden">
          <Link href="/deals/today" className="inline-flex items-center gap-1 text-sm font-semibold text-brand">
            View all today&apos;s deals <ArrowRight size={14} />
          </Link>
        </div>
      </section>

      {/* Flash Deals */}
      <FlashDealsSection deals={flashDeals} endTime={flashEndTime} />

      {/* Biggest Discounts */}
      <section className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <div className="mb-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600 dark:bg-emerald-500/10">
              <TrendingDown size={20} />
            </span>
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 sm:text-2xl dark:text-white">Biggest Discounts</h2>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Up to 80% off, sorted by discount</p>
            </div>
          </div>
          <Link href="/deals/biggest-discounts" className="hidden items-center gap-1 text-sm font-semibold text-brand hover:underline sm:flex">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        <DealGrid deals={biggestDiscounts} />
      </section>

      {/* Under 500 */}
      <section className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <div className="mb-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-100 text-sky-600 dark:bg-sky-500/10">
              <Wallet size={20} />
            </span>
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 sm:text-2xl dark:text-white">Best Deals Under ৳500</h2>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Affordable finds that still pack value</p>
            </div>
          </div>
          <Link href="/deals/under/500" className="hidden items-center gap-1 text-sm font-semibold text-brand hover:underline sm:flex">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        <DealGrid deals={under500} />

        <div className="mt-6 flex flex-wrap gap-3">
          {[1000, 2000, 5000].map((amount) => (
            <Link
              key={amount}
              href={`/deals/under/${amount}`}
              className="rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 transition hover:border-brand/40 hover:text-brand dark:border-white/10 dark:bg-slate-900 dark:text-slate-300"
            >
              Under ৳{amount.toLocaleString()}
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
