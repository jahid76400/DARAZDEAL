import type { Metadata } from "next";
import { Search as SearchIcon } from "lucide-react";
import { getCategories, listDeals } from "@/lib/data";
import { parseDealFilters, type RawSearchParams } from "@/lib/searchParams";
import DealsListingLayout from "@/components/deals/DealsListingLayout";
import SearchBar from "@/components/search/SearchBar";

export const dynamic = "force-dynamic";

export async function generateMetadata({ searchParams }: { searchParams: Promise<RawSearchParams> }): Promise<Metadata> {
  const raw = await searchParams;
  const q = Array.isArray(raw.q) ? raw.q[0] : raw.q;
  return {
    title: q ? `Search results for "${q}"` : "Search Deals",
    description: "Search thousands of verified Daraz deals by product name, brand, or category.",
  };
}

export default async function SearchPage({ searchParams }: { searchParams: Promise<RawSearchParams> }) {
  const rawParams = await searchParams;
  const filters = parseDealFilters(rawParams);
  const q = filters.query ?? "";
  const [deals, categories] = await Promise.all([
    q ? listDeals(filters) : Promise.resolve([]),
    getCategories(),
  ]);

  return (
    <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
      <div className="mx-auto max-w-xl">
        <SearchBar initialValue={q} size="lg" placeholder="Search earbuds, watches, brands..." />
      </div>

      <div className="mt-8">
        <DealsListingLayout
          title={q ? `Results for "${q}"` : "Search for Daraz deals"}
          subtitle={q ? `${deals.length} deal${deals.length === 1 ? "" : "s"} matched your search` : "Try searching for a product, brand, or category"}
          icon={
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft text-brand dark:bg-brand/15">
              <SearchIcon size={22} />
            </span>
          }
          deals={deals}
          categories={categories}
          breadcrumbs={[{ label: "Home", href: "/" }, { label: "Search" }]}
          resultCountLabel={q ? undefined : " "}
        />
      </div>
    </main>
  );
}
