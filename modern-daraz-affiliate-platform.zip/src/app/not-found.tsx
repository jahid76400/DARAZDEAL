import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-[60vh] flex-col items-center justify-center px-4 text-center">
      <p className="text-6xl">🛒</p>
      <h1 className="mt-4 text-2xl font-extrabold text-slate-900 dark:text-white">Deal not found</h1>
      <p className="mt-2 max-w-sm text-sm text-slate-500 dark:text-slate-400">
        This deal may have expired or been removed. Explore today&apos;s active Daraz deals instead.
      </p>
      <Link href="/" className="mt-6 rounded-full bg-brand px-6 py-3 text-sm font-bold text-white">
        Back to Home
      </Link>
    </main>
  );
}
