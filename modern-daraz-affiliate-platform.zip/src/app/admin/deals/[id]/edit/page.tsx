import { notFound, redirect } from "next/navigation";
import { isAdminAuthenticated } from "@/lib/auth";
import { getCategories, getDealById } from "@/lib/data";
import AdminTopBar from "@/components/admin/AdminTopBar";
import AdminDealForm from "@/components/admin/AdminDealForm";

export const dynamic = "force-dynamic";

export default async function EditDealPage({ params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdminAuthenticated())) {
    redirect("/admin/login");
  }

  const { id } = await params;
  const [categories, deal] = await Promise.all([getCategories(), getDealById(Number(id))]);
  if (!deal) notFound();

  return (
    <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <AdminTopBar />
      <h1 className="mb-6 text-2xl font-extrabold text-slate-900 dark:text-white">Edit Deal</h1>
      <AdminDealForm categories={categories} deal={deal} />
    </main>
  );
}
