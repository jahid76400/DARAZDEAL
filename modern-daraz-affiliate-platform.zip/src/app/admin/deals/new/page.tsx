import { redirect } from "next/navigation";
import { isAdminAuthenticated } from "@/lib/auth";
import { getCategories } from "@/lib/data";
import AdminTopBar from "@/components/admin/AdminTopBar";
import AdminDealForm from "@/components/admin/AdminDealForm";

export const dynamic = "force-dynamic";

export default async function NewDealPage() {
  if (!(await isAdminAuthenticated())) {
    redirect("/admin/login");
  }

  const categories = await getCategories();

  return (
    <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <AdminTopBar />
      <h1 className="mb-6 text-2xl font-extrabold text-slate-900 dark:text-white">Add New Deal</h1>
      <AdminDealForm categories={categories} />
    </main>
  );
}
