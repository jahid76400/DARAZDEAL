import { redirect } from "next/navigation";
import { isAdminAuthenticated } from "@/lib/auth";
import { getAnalyticsOverview, listAllDealsForAdmin } from "@/lib/data";
import AdminTopBar from "@/components/admin/AdminTopBar";
import AnalyticsOverview from "@/components/admin/AnalyticsOverview";
import DealsTable from "@/components/admin/DealsTable";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  if (!(await isAdminAuthenticated())) {
    redirect("/admin/login");
  }

  const [overview, deals] = await Promise.all([getAnalyticsOverview(), listAllDealsForAdmin()]);

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <AdminTopBar />
      <h1 className="mb-1 text-2xl font-extrabold text-slate-900 dark:text-white">Dashboard</h1>
      <p className="mb-6 text-sm text-slate-500 dark:text-slate-400">
        Manage deals, track performance, and keep your Daraz affiliate links up to date.
      </p>

      <AnalyticsOverview overview={overview} />

      <div className="mt-10">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">All Deals ({deals.length})</h2>
        </div>
        <DealsTable deals={deals} />
      </div>
    </main>
  );
}
