import { NextRequest } from "next/server";
import { listDeals } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const q = request.nextUrl.searchParams.get("q")?.trim() ?? "";
  if (q.length < 2) {
    return Response.json({ results: [] });
  }

  const deals = await listDeals({ query: q, limit: 6 });
  return Response.json({
    results: deals.map((d) => ({ slug: d.slug, productName: d.productName, categoryName: d.categoryName })),
  });
}
