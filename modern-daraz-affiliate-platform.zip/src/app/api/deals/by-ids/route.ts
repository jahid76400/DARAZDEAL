import { NextRequest } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { categories, deals } from "@/db/schema";
import { computePricing } from "@/lib/pricing";
import type { Deal } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const idsParam = request.nextUrl.searchParams.get("ids") ?? "";
  const ids = idsParam
    .split(",")
    .map((id) => Number(id))
    .filter((id) => Number.isFinite(id));

  if (ids.length === 0) {
    return Response.json({ deals: [] });
  }

  const rows = await db
    .select({
      id: deals.id,
      productName: deals.productName,
      slug: deals.slug,
      productImage: deals.productImage,
      categoryId: deals.categoryId,
      brand: deals.brand,
      regularPrice: deals.regularPrice,
      salePrice: deals.salePrice,
      rating: deals.rating,
      reviewCount: deals.reviewCount,
      affiliateUrl: deals.affiliateUrl,
      description: deals.description,
      dealStart: deals.dealStart,
      dealEnd: deals.dealEnd,
      status: deals.status,
      featured: deals.featured,
      isFlashDeal: deals.isFlashDeal,
      viewCount: deals.viewCount,
      clickCount: deals.clickCount,
      createdAt: deals.createdAt,
      updatedAt: deals.updatedAt,
      categoryName: categories.name,
      categorySlug: categories.slug,
    })
    .from(deals)
    .leftJoin(categories, eq(deals.categoryId, categories.id))
    .where(inArray(deals.id, ids));

  const result: Deal[] = rows.map((row) => {
    const regularPrice = Number(row.regularPrice);
    const salePrice = Number(row.salePrice);
    const pricing = computePricing({ regularPrice, salePrice });
    const now = Date.now();
    const dealEndTime = row.dealEnd ? new Date(row.dealEnd).getTime() : null;
    const isExpired = row.status === "expired" || (dealEndTime !== null && dealEndTime <= now);

    return {
      id: row.id,
      productName: row.productName,
      slug: row.slug,
      productImage: row.productImage,
      categoryId: row.categoryId,
      categoryName: row.categoryName ?? "Others",
      categorySlug: row.categorySlug ?? "others",
      brand: row.brand,
      regularPrice,
      salePrice,
      discountPercentage: pricing.discountPercentage,
      savingsAmount: pricing.savingsAmount,
      rating: Number(row.rating),
      reviewCount: row.reviewCount,
      affiliateUrl: row.affiliateUrl,
      description: row.description,
      dealStart: row.dealStart.toISOString(),
      dealEnd: row.dealEnd ? row.dealEnd.toISOString() : null,
      status: isExpired ? "expired" : row.status,
      featured: row.featured,
      isFlashDeal: row.isFlashDeal,
      viewCount: row.viewCount,
      clickCount: row.clickCount,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
      isExpired,
    };
  });

  return Response.json({ deals: result });
}
