import { NextRequest } from "next/server";
import { recordDealEvent } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const dealId = Number(body?.dealId);
    if (!Number.isFinite(dealId)) {
      return Response.json({ ok: false }, { status: 400 });
    }
    await recordDealEvent(dealId, "click");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
