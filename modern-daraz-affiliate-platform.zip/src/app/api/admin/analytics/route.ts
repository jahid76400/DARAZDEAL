import { isAdminAuthenticated } from "@/lib/auth";
import { getAnalyticsOverview } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAdminAuthenticated())) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  const overview = await getAnalyticsOverview();
  return Response.json(overview);
}
