import { NextRequest } from "next/server";
import { isAdminAuthenticated } from "@/lib/auth";
import { listAllDealsForAdmin } from "@/lib/data";
import { createDeal, type DealInput } from "@/lib/mutations";

export const dynamic = "force-dynamic";

function parseInput(body: Record<string, unknown>): DealInput {
  return {
    productName: String(body.productName ?? "").trim(),
    slug: body.slug ? String(body.slug).trim() : undefined,
    productImage: String(body.productImage ?? "").trim(),
    categoryId: Number(body.categoryId),
    brand: String(body.brand ?? "Generic").trim(),
    regularPrice: Number(body.regularPrice),
    salePrice: Number(body.salePrice),
    rating: Number(body.rating ?? 4.5),
    reviewCount: Number(body.reviewCount ?? 0),
    affiliateUrl: String(body.affiliateUrl ?? "").trim(),
    description: String(body.description ?? ""),
    dealEnd: body.dealEnd ? String(body.dealEnd) : null,
    status: (body.status as DealInput["status"]) ?? "active",
    featured: Boolean(body.featured),
    isFlashDeal: Boolean(body.isFlashDeal),
  };
}

export async function GET() {
  if (!(await isAdminAuthenticated())) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  const deals = await listAllDealsForAdmin();
  return Response.json({ deals });
}

export async function POST(request: NextRequest) {
  if (!(await isAdminAuthenticated())) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const input = parseInput(body);

  if (!input.productName || !input.productImage || !input.affiliateUrl || !Number.isFinite(input.categoryId)) {
    return Response.json({ error: "Missing required fields" }, { status: 400 });
  }

  const deal = await createDeal(input);
  return Response.json({ deal }, { status: 201 });
}
