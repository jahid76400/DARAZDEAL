import { NextRequest } from "next/server";
import { isAdminAuthenticated } from "@/lib/auth";
import { deleteDeal, updateDeal, type DealInput } from "@/lib/mutations";
import { getDealById } from "@/lib/data";

export const dynamic = "force-dynamic";

function parseInput(body: Record<string, unknown>): DealInput {
  return {
    productName: String(body.productName ?? "").trim(),
    slug: body.slug ? String(body.slug).trim() : undefined,
    productImage: String(body.productImage ?? "").trim(),
    categoryId: Number(body.categoryId),
    brand: String(body.brand ?? "Generic").trim(),
    regularPrice: Number(body.regularPrice),
    salePrice: Number(body.salePrice),
    rating: Number(body.rating ?? 4.5),
    reviewCount: Number(body.reviewCount ?? 0),
    affiliateUrl: String(body.affiliateUrl ?? "").trim(),
    description: String(body.description ?? ""),
    dealEnd: body.dealEnd ? String(body.dealEnd) : null,
    status: (body.status as DealInput["status"]) ?? "active",
    featured: Boolean(body.featured),
    isFlashDeal: Boolean(body.isFlashDeal),
  };
}

export async function GET(_request: NextRequest, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminAuthenticated())) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await context.params;
  const deal = await getDealById(Number(id));
  if (!deal) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json({ deal });
}

export async function PATCH(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminAuthenticated())) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await context.params;
  const body = await request.json();
  const input = parseInput(body);
  const deal = await updateDeal(Number(id), input);
  return Response.json({ deal });
}

export async function DELETE(_request: NextRequest, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminAuthenticated())) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await context.params;
  await deleteDeal(Number(id));
  return Response.json({ ok: true });
}
