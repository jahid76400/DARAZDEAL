import { NextRequest } from "next/server";
import { isAdminAuthenticated } from "@/lib/auth";
import { deleteCategory } from "@/lib/mutations";

export const dynamic = "force-dynamic";

export async function DELETE(_request: NextRequest, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminAuthenticated())) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await context.params;
  await deleteCategory(Number(id));
  return Response.json({ ok: true });
}
