import { NextRequest } from "next/server";
import { isAdminAuthenticated } from "@/lib/auth";
import { getCategories } from "@/lib/data";
import { createCategory } from "@/lib/mutations";

export const dynamic = "force-dynamic";

export async function GET() {
  const categories = await getCategories();
  return Response.json({ categories });
}

export async function POST(request: NextRequest) {
  if (!(await isAdminAuthenticated())) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  const body = await request.json();
  const category = await createCategory({
    name: String(body.name ?? "").trim(),
    slug: body.slug ? String(body.slug) : undefined,
    icon: String(body.icon ?? "Sparkles"),
    description: body.description ? String(body.description) : undefined,
  });
  return Response.json({ category }, { status: 201 });
}
