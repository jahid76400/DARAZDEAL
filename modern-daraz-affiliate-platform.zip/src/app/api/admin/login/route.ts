import { NextRequest } from "next/server";
import { setAdminSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  const password = String(body?.password ?? "");
  const expected = process.env.ADMIN_PASSWORD;

  if (!expected || password !== expected) {
    return Response.json({ ok: false, error: "Invalid password" }, { status: 401 });
  }

  await setAdminSession();
  return Response.json({ ok: true });
}
