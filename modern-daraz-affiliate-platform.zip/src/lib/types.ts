export type DealStatus = "active" | "expired" | "draft";

export type Category = {
  id: number;
  name: string;
  slug: string;
  icon: string;
  description: string | null;
};

export type Deal = {
  id: number;
  productName: string;
  slug: string;
  productImage: string;
  categoryId: number;
  categoryName: string;
  categorySlug: string;
  brand: string;
  regularPrice: number;
  salePrice: number;
  discountPercentage: number;
  savingsAmount: number;
  rating: number;
  reviewCount: number;
  affiliateUrl: string;
  description: string;
  dealStart: string;
  dealEnd: string | null;
  status: DealStatus;
  featured: boolean;
  isFlashDeal: boolean;
  viewCount: number;
  clickCount: number;
  createdAt: string;
  updatedAt: string;
  isExpired: boolean;
};

export type DealFilters = {
  query?: string;
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  minDiscount?: number;
  sort?: "discount" | "price-asc" | "price-desc" | "popular" | "newest";
  featuredOnly?: boolean;
  flashOnly?: boolean;
  includeExpired?: boolean;
  limit?: number;
};
