import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, deals } from "@/db/schema";
import { computePricing } from "@/lib/pricing";

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 180);
}

export type DealInput = {
  productName: string;
  slug?: string;
  productImage: string;
  categoryId: number;
  brand: string;
  regularPrice: number;
  salePrice: number;
  rating: number;
  reviewCount: number;
  affiliateUrl: string;
  description: string;
  dealEnd: string | null;
  status: "active" | "expired" | "draft";
  featured: boolean;
  isFlashDeal: boolean;
};

export async function createDeal(input: DealInput) {
  const pricing = computePricing({ regularPrice: input.regularPrice, salePrice: input.salePrice });
  const baseSlug = slugify(input.slug && input.slug.length > 0 ? input.slug : input.productName);
  let slug = baseSlug;
  let attempt = 1;
  while (await db.select({ id: deals.id }).from(deals).where(eq(deals.slug, slug)).then((r) => r.length > 0)) {
    attempt += 1;
    slug = `${baseSlug}-${attempt}`;
  }

  const [row] = await db
    .insert(deals)
    .values({
      productName: input.productName,
      slug,
      productImage: input.productImage,
      categoryId: input.categoryId,
      brand: input.brand,
      regularPrice: input.regularPrice.toString(),
      salePrice: input.salePrice.toString(),
      discountPercentage: pricing.discountPercentage.toString(),
      savingsAmount: pricing.savingsAmount.toString(),
      rating: input.rating.toString(),
      reviewCount: input.reviewCount,
      affiliateUrl: input.affiliateUrl,
      description: input.description,
      dealEnd: input.dealEnd ? new Date(input.dealEnd) : null,
      status: input.status,
      featured: input.featured,
      isFlashDeal: input.isFlashDeal,
      updatedAt: new Date(),
    })
    .returning();

  return row;
}

export async function updateDeal(id: number, input: DealInput) {
  const pricing = computePricing({ regularPrice: input.regularPrice, salePrice: input.salePrice });

  const [row] = await db
    .update(deals)
    .set({
      productName: input.productName,
      productImage: input.productImage,
      categoryId: input.categoryId,
      brand: input.brand,
      regularPrice: input.regularPrice.toString(),
      salePrice: input.salePrice.toString(),
      discountPercentage: pricing.discountPercentage.toString(),
      savingsAmount: pricing.savingsAmount.toString(),
      rating: input.rating.toString(),
      reviewCount: input.reviewCount,
      affiliateUrl: input.affiliateUrl,
      description: input.description,
      dealEnd: input.dealEnd ? new Date(input.dealEnd) : null,
      status: input.status,
      featured: input.featured,
      isFlashDeal: input.isFlashDeal,
      updatedAt: new Date(),
    })
    .where(eq(deals.id, id))
    .returning();

  return row;
}

export async function deleteDeal(id: number) {
  await db.delete(deals).where(eq(deals.id, id));
}

export async function createCategory(input: { name: string; slug?: string; icon: string; description?: string }) {
  const slug = slugify(input.slug && input.slug.length > 0 ? input.slug : input.name);
  const [row] = await db
    .insert(categories)
    .values({
      name: input.name,
      slug,
      icon: input.icon,
      description: input.description ?? null,
    })
    .returning();
  return row;
}

export async function deleteCategory(id: number) {
  await db.delete(categories).where(eq(categories.id, id));
}
