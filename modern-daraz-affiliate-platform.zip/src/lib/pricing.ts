export type PricingInput = {
  regularPrice: number;
  salePrice: number;
};

export type PricingResult = {
  hasDiscount: boolean;
  discountPercentage: number;
  savingsAmount: number;
};

/**
 * Single source of truth for discount math across the whole app.
 * We never trust a manually entered discount percentage — it is always
 * derived from the regular price and the sale price.
 */
export function computePricing({ regularPrice, salePrice }: PricingInput): PricingResult {
  if (!Number.isFinite(regularPrice) || !Number.isFinite(salePrice) || regularPrice <= 0) {
    return { hasDiscount: false, discountPercentage: 0, savingsAmount: 0 };
  }

  if (salePrice >= regularPrice) {
    return { hasDiscount: false, discountPercentage: 0, savingsAmount: 0 };
  }

  const savingsAmount = Math.round((regularPrice - salePrice) * 100) / 100;
  const discountPercentage = Math.round(((regularPrice - salePrice) / regularPrice) * 100);

  return {
    hasDiscount: discountPercentage > 0,
    discountPercentage,
    savingsAmount,
  };
}
