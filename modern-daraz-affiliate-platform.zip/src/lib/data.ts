import { and, asc, desc, eq, gte, ilike, lte, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { categories, dealEvents, deals } from "@/db/schema";
import { computePricing } from "@/lib/pricing";
import type { Category, Deal, DealFilters } from "@/lib/types";

type DealRow = typeof deals.$inferSelect & {
  categoryName: string | null;
  categorySlug: string | null;
};

function mapDeal(row: DealRow): Deal {
  const regularPrice = Number(row.regularPrice);
  const salePrice = Number(row.salePrice);
  const pricing = computePricing({ regularPrice, salePrice });
  const now = Date.now();
  const dealEndTime = row.dealEnd ? new Date(row.dealEnd).getTime() : null;
  const isExpired = row.status === "expired" || (dealEndTime !== null && dealEndTime <= now);

  return {
    id: row.id,
    productName: row.productName,
    slug: row.slug,
    productImage: row.productImage,
    categoryId: row.categoryId,
    categoryName: row.categoryName ?? "Others",
    categorySlug: row.categorySlug ?? "others",
    brand: row.brand,
    regularPrice,
    salePrice,
    discountPercentage: pricing.discountPercentage,
    savingsAmount: pricing.savingsAmount,
    rating: Number(row.rating),
    reviewCount: row.reviewCount,
    affiliateUrl: row.affiliateUrl,
    description: row.description,
    dealStart: row.dealStart.toISOString(),
    dealEnd: row.dealEnd ? row.dealEnd.toISOString() : null,
    status: isExpired ? "expired" : row.status,
    featured: row.featured,
    isFlashDeal: row.isFlashDeal,
    viewCount: row.viewCount,
    clickCount: row.clickCount,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    isExpired,
  };
}

const baseSelect = () =>
  db
    .select({
      id: deals.id,
      productName: deals.productName,
      slug: deals.slug,
      productImage: deals.productImage,
      categoryId: deals.categoryId,
      brand: deals.brand,
      regularPrice: deals.regularPrice,
      salePrice: deals.salePrice,
      discountPercentage: deals.discountPercentage,
      savingsAmount: deals.savingsAmount,
      rating: deals.rating,
      reviewCount: deals.reviewCount,
      affiliateUrl: deals.affiliateUrl,
      description: deals.description,
      dealStart: deals.dealStart,
      dealEnd: deals.dealEnd,
      status: deals.status,
      featured: deals.featured,
      isFlashDeal: deals.isFlashDeal,
      viewCount: deals.viewCount,
      clickCount: deals.clickCount,
      createdAt: deals.createdAt,
      updatedAt: deals.updatedAt,
      categoryName: categories.name,
      categorySlug: categories.slug,
    })
    .from(deals)
    .leftJoin(categories, eq(deals.categoryId, categories.id));

export async function listDeals(filters: DealFilters = {}): Promise<Deal[]> {
  const conditions = [];

  if (!filters.includeExpired) {
    conditions.push(eq(deals.status, "active"));
  }

  if (filters.category) {
    conditions.push(eq(categories.slug, filters.category));
  }

  if (filters.query) {
    const term = `%${filters.query}%`;
    conditions.push(
      or(
        ilike(deals.productName, term),
        ilike(deals.brand, term),
        ilike(categories.name, term),
        ilike(deals.description, term),
      ),
    );
  }

  if (typeof filters.minPrice === "number") {
    conditions.push(gte(deals.salePrice, filters.minPrice.toString()));
  }

  if (typeof filters.maxPrice === "number") {
    conditions.push(lte(deals.salePrice, filters.maxPrice.toString()));
  }

  if (filters.featuredOnly) {
    conditions.push(eq(deals.featured, true));
  }

  if (filters.flashOnly) {
    conditions.push(eq(deals.isFlashDeal, true));
  }

  let orderBy = desc(deals.discountPercentage);
  switch (filters.sort) {
    case "price-asc":
      orderBy = asc(deals.salePrice);
      break;
    case "price-desc":
      orderBy = desc(deals.salePrice);
      break;
    case "popular":
      orderBy = desc(deals.viewCount);
      break;
    case "newest":
      orderBy = desc(deals.createdAt);
      break;
    default:
      orderBy = desc(deals.discountPercentage);
  }

  const query = baseSelect();
  const rows = conditions.length
    ? await query.where(and(...conditions)).orderBy(orderBy, desc(deals.id))
    : await query.orderBy(orderBy, desc(deals.id));

  let result = rows.map(mapDeal);

  if (typeof filters.minDiscount === "number") {
    result = result.filter((d) => d.discountPercentage >= filters.minDiscount!);
  }

  if (filters.sort === "discount" || !filters.sort) {
    result = result.sort((a, b) => b.discountPercentage - a.discountPercentage);
  }

  if (filters.limit) {
    result = result.slice(0, filters.limit);
  }

  return result;
}

export async function getDealBySlug(slug: string): Promise<Deal | null> {
  const rows = await baseSelect().where(eq(deals.slug, slug)).limit(1);
  if (!rows.length) return null;
  return mapDeal(rows[0]);
}

export async function getDealById(id: number): Promise<Deal | null> {
  const rows = await baseSelect().where(eq(deals.id, id)).limit(1);
  if (!rows.length) return null;
  return mapDeal(rows[0]);
}

export async function listAllDealsForAdmin(): Promise<Deal[]> {
  const rows = await baseSelect().orderBy(desc(deals.createdAt));
  return rows.map(mapDeal);
}

export async function getCategories(): Promise<Category[]> {
  const rows = await db.select().from(categories).orderBy(asc(categories.name));
  return rows.map((row) => ({
    id: row.id,
    name: row.name,
    slug: row.slug,
    icon: row.icon,
    description: row.description,
  }));
}

export async function getCategoryBySlug(slug: string): Promise<Category | null> {
  const rows = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
  if (!rows.length) return null;
  const row = rows[0];
  return { id: row.id, name: row.name, slug: row.slug, icon: row.icon, description: row.description };
}

export async function getCategoryDealCounts(): Promise<Record<string, number>> {
  const rows = await db
    .select({ slug: categories.slug, count: sql<number>`count(${deals.id})`.mapWith(Number) })
    .from(categories)
    .leftJoin(deals, and(eq(deals.categoryId, categories.id), eq(deals.status, "active")))
    .groupBy(categories.slug);

  return Object.fromEntries(rows.map((row) => [row.slug, row.count]));
}

export async function recordDealEvent(dealId: number, type: "view" | "click") {
  await db.insert(dealEvents).values({ dealId, type });
  if (type === "view") {
    await db.update(deals).set({ viewCount: sql`${deals.viewCount} + 1` }).where(eq(deals.id, dealId));
  } else {
    await db.update(deals).set({ clickCount: sql`${deals.clickCount} + 1` }).where(eq(deals.id, dealId));
  }
}

export async function getAnalyticsOverview() {
  const [totals] = await db
    .select({
      totalViews: sql<number>`coalesce(sum(${deals.viewCount}), 0)`.mapWith(Number),
      totalClicks: sql<number>`coalesce(sum(${deals.clickCount}), 0)`.mapWith(Number),
      totalDeals: sql<number>`count(*)`.mapWith(Number),
      activeDeals: sql<number>`count(*) filter (where ${deals.status} = 'active')`.mapWith(Number),
    })
    .from(deals);

  const topViewed = await listAllDealsForAdmin();
  const byViews = [...topViewed].sort((a, b) => b.viewCount - a.viewCount).slice(0, 8);
  const byClicks = [...topViewed].sort((a, b) => b.clickCount - a.clickCount).slice(0, 8);

  const categoryStats = await db
    .select({
      categoryName: categories.name,
      views: sql<number>`coalesce(sum(${deals.viewCount}), 0)`.mapWith(Number),
      clicks: sql<number>`coalesce(sum(${deals.clickCount}), 0)`.mapWith(Number),
      dealCount: sql<number>`count(${deals.id})`.mapWith(Number),
    })
    .from(categories)
    .leftJoin(deals, eq(deals.categoryId, categories.id))
    .groupBy(categories.name)
    .orderBy(desc(sql`coalesce(sum(${deals.clickCount}), 0)`));

  const dailyEvents = await db
    .select({
      day: sql<string>`to_char(${dealEvents.createdAt}, 'YYYY-MM-DD')`,
      type: dealEvents.type,
      count: sql<number>`count(*)`.mapWith(Number),
    })
    .from(dealEvents)
    .where(gte(dealEvents.createdAt, sql`now() - interval '30 days'`))
    .groupBy(sql`to_char(${dealEvents.createdAt}, 'YYYY-MM-DD')`, dealEvents.type)
    .orderBy(sql`to_char(${dealEvents.createdAt}, 'YYYY-MM-DD')`);

  const ctr = totals.totalViews > 0 ? (totals.totalClicks / totals.totalViews) * 100 : 0;

  return {
    totals: { ...totals, ctr },
    topViewed: byViews,
    topClicked: byClicks,
    categoryStats,
    dailyEvents,
  };
}
