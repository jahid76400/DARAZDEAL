import type { DealFilters } from "@/lib/types";

export type RawSearchParams = Record<string, string | string[] | undefined>;

function first(value: string | string[] | undefined): string | undefined {
  return Array.isArray(value) ? value[0] : value;
}

export function parseDealFilters(raw: RawSearchParams): DealFilters {
  const minPrice = first(raw.minPrice);
  const maxPrice = first(raw.maxPrice);
  const minDiscount = first(raw.minDiscount);
  const category = first(raw.category);
  const sort = first(raw.sort) as DealFilters["sort"] | undefined;
  const query = first(raw.q);

  return {
    query: query || undefined,
    category: category || undefined,
    minPrice: minPrice ? Number(minPrice) : undefined,
    maxPrice: maxPrice ? Number(maxPrice) : undefined,
    minDiscount: minDiscount ? Number(minDiscount) : undefined,
    sort: sort || undefined,
  };
}
