"use client";

import { useCallback, useEffect, useState } from "react";

function readList(key: string): number[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((item) => typeof item === "number") : [];
  } catch {
    return [];
  }
}

export function useLocalStorageList(key: string, limit?: number) {
  const [items, setItems] = useState<number[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setItems(readList(key));
    setHydrated(true);
  }, [key]);

  const persist = useCallback(
    (next: number[]) => {
      setItems(next);
      try {
        window.localStorage.setItem(key, JSON.stringify(next));
        window.dispatchEvent(new CustomEvent("dealbazi-storage", { detail: { key } }));
      } catch {
        // ignore storage failures (private mode, quota, etc.)
      }
    },
    [key],
  );

  useEffect(() => {
    function handleExternalUpdate(event: Event) {
      const custom = event as CustomEvent<{ key: string }>;
      if (custom.detail?.key === key) {
        setItems(readList(key));
      }
    }
    window.addEventListener("dealbazi-storage", handleExternalUpdate);
    window.addEventListener("storage", handleExternalUpdate);
    return () => {
      window.removeEventListener("dealbazi-storage", handleExternalUpdate);
      window.removeEventListener("storage", handleExternalUpdate);
    };
  }, [key]);

  const add = useCallback(
    (id: number) => {
      const withoutId = items.filter((item) => item !== id);
      const next = [id, ...withoutId];
      persist(limit ? next.slice(0, limit) : next);
    },
    [items, limit, persist],
  );

  const remove = useCallback(
    (id: number) => {
      persist(items.filter((item) => item !== id));
    },
    [items, persist],
  );

  const toggle = useCallback(
    (id: number) => {
      if (items.includes(id)) {
        remove(id);
      } else {
        add(id);
      }
    },
    [items, add, remove],
  );

  const has = useCallback((id: number) => items.includes(id), [items]);

  return { items, hydrated, add, remove, toggle, has };
}
