"use client";

import { useLocalStorageList } from "@/lib/hooks/useLocalStorageList";

export function useWishlist() {
  const list = useLocalStorageList("dealbazi-wishlist");
  return {
    wishlist: list.items,
    hydrated: list.hydrated,
    isWishlisted: list.has,
    toggleWishlist: list.toggle,
    removeFromWishlist: list.remove,
  };
}

export function useRecentlyViewed() {
  const list = useLocalStorageList("dealbazi-recently-viewed", 12);
  return {
    recentlyViewed: list.items,
    hydrated: list.hydrated,
    markViewed: list.add,
  };
}
