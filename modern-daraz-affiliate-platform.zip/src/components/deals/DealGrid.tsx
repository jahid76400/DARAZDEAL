import DealCard from "@/components/deals/DealCard";
import type { Deal } from "@/lib/types";

export default function DealGrid({
  deals,
  emptyMessage = "No deals found. Try adjusting your filters.",
}: {
  deals: Deal[];
  emptyMessage?: string;
}) {
  if (deals.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white/60 px-6 py-16 text-center dark:border-slate-700 dark:bg-slate-900/40">
        <p className="text-3xl">🔍</p>
        <p className="mt-3 text-sm font-medium text-slate-500 dark:text-slate-400">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
      {deals.map((deal, idx) => (
        <DealCard key={deal.id} deal={deal} priority={idx < 4} />
      ))}
    </div>
  );
}
