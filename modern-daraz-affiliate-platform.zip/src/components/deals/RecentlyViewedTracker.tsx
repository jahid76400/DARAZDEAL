"use client";

import { useEffect } from "react";
import { useRecentlyViewed } from "@/lib/hooks/useWishlist";

export default function RecentlyViewedTracker({ dealId }: { dealId: number }) {
  const { markViewed } = useRecentlyViewed();

  useEffect(() => {
    markViewed(dealId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dealId]);

  return null;
}
