"use client";

import { Heart } from "lucide-react";
import { useState } from "react";
import { useWishlist } from "@/lib/hooks/useWishlist";
import clsx from "clsx";

export default function WishlistButton({
  dealId,
  size = "md",
}: {
  dealId: number;
  size?: "sm" | "md" | "lg";
}) {
  const { isWishlisted, toggleWishlist, hydrated } = useWishlist();
  const [popped, setPopped] = useState(false);
  const active = hydrated && isWishlisted(dealId);

  const dims = size === "sm" ? "h-8 w-8" : size === "lg" ? "h-12 w-12" : "h-9 w-9";
  const iconSize = size === "sm" ? 15 : size === "lg" ? 22 : 17;

  return (
    <button
      type="button"
      aria-label={active ? "Remove from wishlist" : "Add to wishlist"}
      onClick={(event) => {
        event.preventDefault();
        event.stopPropagation();
        toggleWishlist(dealId);
        setPopped(true);
        setTimeout(() => setPopped(false), 400);
      }}
      className={clsx(
        dims,
        "flex shrink-0 items-center justify-center rounded-full border backdrop-blur-sm transition-all duration-200",
        active
          ? "border-brand bg-brand text-white shadow-md shadow-brand/30"
          : "border-slate-200/80 bg-white/90 text-slate-500 hover:border-brand/50 hover:text-brand dark:border-white/10 dark:bg-slate-900/80 dark:text-slate-300",
      )}
    >
      <Heart
        size={iconSize}
        className={clsx(popped && "heart-pop", active && "fill-current")}
        strokeWidth={2.2}
      />
    </button>
  );
}
