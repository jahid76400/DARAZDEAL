import type { ReactNode } from "react";
import DealGrid from "@/components/deals/DealGrid";
import FilterPanel from "@/components/filters/FilterPanel";
import Breadcrumbs, { type Crumb } from "@/components/deals/Breadcrumbs";
import type { Category, Deal } from "@/lib/types";

export default function DealsListingLayout({
  title,
  subtitle,
  icon,
  deals,
  categories,
  breadcrumbs,
  hideCategoryFilter = false,
  resultCountLabel,
}: {
  title: string;
  subtitle?: string;
  icon?: ReactNode;
  deals: Deal[];
  categories: Category[];
  breadcrumbs: Crumb[];
  hideCategoryFilter?: boolean;
  resultCountLabel?: string;
}) {
  return (
    <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
      <Breadcrumbs items={breadcrumbs} />

      <div className="mt-3 flex items-center gap-3">
        {icon}
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 sm:text-3xl dark:text-white">{title}</h1>
          {subtitle && <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{subtitle}</p>}
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[260px_1fr]">
        <aside className="lg:sticky lg:top-20 lg:self-start">
          <FilterPanel categories={categories} hideCategory={hideCategoryFilter} />
        </aside>

        <div>
          <p className="mb-3 text-xs font-semibold text-slate-400">
            {resultCountLabel ?? `${deals.length} deal${deals.length === 1 ? "" : "s"} found`}
          </p>
          <DealGrid deals={deals} />
        </div>
      </div>
    </main>
  );
}
