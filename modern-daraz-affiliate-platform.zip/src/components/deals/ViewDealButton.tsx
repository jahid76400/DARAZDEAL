"use client";

import { ArrowUpRight } from "lucide-react";
import clsx from "clsx";
import type { Deal } from "@/lib/types";

export default function ViewDealButton({
  deal,
  className,
  label = "View Deal",
}: {
  deal: Deal;
  className?: string;
  label?: string;
}) {
  const disabled = deal.isExpired;

  function handleClick(event: React.MouseEvent) {
    event.preventDefault();
    if (disabled) return;

    try {
      const payload = JSON.stringify({ dealId: deal.id });
      if (navigator.sendBeacon) {
        navigator.sendBeacon("/api/track/click", new Blob([payload], { type: "application/json" }));
      } else {
        fetch("/api/track/click", { method: "POST", body: payload, keepalive: true });
      }
    } catch {
      // tracking should never block the redirect
    }

    window.open(deal.affiliateUrl, "_blank", "noopener,noreferrer");
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={disabled}
      className={clsx(
        "inline-flex items-center gap-1.5 bg-brand font-bold text-white transition-all duration-200 hover:bg-brand-dark active:scale-[0.98]",
        "disabled:cursor-not-allowed disabled:bg-slate-300 disabled:text-slate-500 dark:disabled:bg-slate-700 dark:disabled:text-slate-400",
        className,
      )}
    >
      {disabled ? "Deal Expired" : label}
      {!disabled && <ArrowUpRight size={16} strokeWidth={2.5} />}
    </button>
  );
}
