import Link from "next/link";
import { Zap, ArrowRight } from "lucide-react";
import DealCard from "@/components/deals/DealCard";
import CountdownTimer from "@/components/deals/CountdownTimer";
import type { Deal } from "@/lib/types";

export default function FlashDealsSection({ deals, endTime }: { deals: Deal[]; endTime: string }) {
  if (deals.length === 0) return null;

  return (
    <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-brand/90 p-5 sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="animate-pulse-ring flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-400 text-slate-900">
              <Zap size={22} fill="currentColor" />
            </span>
            <div>
              <h2 className="text-xl font-extrabold text-white sm:text-2xl">Flash Deals</h2>
              <p className="text-xs text-white/70">Grab them before time runs out</p>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-2xl bg-black/20 px-4 py-2.5">
            <CountdownTimer endTime={endTime} />
          </div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
          {deals.slice(0, 4).map((deal) => (
            <div key={deal.id} className="rounded-2xl bg-white dark:bg-slate-900">
              <DealCard deal={deal} />
            </div>
          ))}
        </div>

        <div className="mt-6 text-center">
          <Link
            href="/deals/flash"
            className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-white/20"
          >
            View all flash deals <ArrowRight size={15} />
          </Link>
        </div>
      </div>
    </section>
  );
}
