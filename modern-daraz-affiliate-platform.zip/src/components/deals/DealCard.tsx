import Image from "next/image";
import Link from "next/link";
import { Star } from "lucide-react";
import { formatBDT, formatCompactNumber } from "@/lib/format";
import type { Deal } from "@/lib/types";
import WishlistButton from "@/components/deals/WishlistButton";
import ViewDealButton from "@/components/deals/ViewDealButton";

export default function DealCard({ deal, priority = false }: { deal: Deal; priority?: boolean }) {
  const expired = deal.isExpired;

  return (
    <div className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-slate-200/70 bg-white shadow-[0_1px_2px_rgba(16,24,40,0.06)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_18px_40px_rgba(16,24,40,0.12)] dark:border-white/10 dark:bg-slate-900">
      <Link href={`/deal/${deal.slug}`} className="relative block aspect-square overflow-hidden bg-slate-100 dark:bg-slate-800">
        <Image
          src={deal.productImage}
          alt={deal.productName}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
          priority={priority}
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {deal.discountPercentage > 0 && !expired && (
          <span className="absolute left-2 top-2 rounded-full bg-brand px-2.5 py-1 text-[11px] font-bold text-white shadow-md shadow-brand/30">
            🔥 {deal.discountPercentage}% OFF
          </span>
        )}
        {expired && (
          <span className="absolute left-2 top-2 rounded-full bg-slate-800/90 px-2.5 py-1 text-[11px] font-bold text-white">
            Deal Expired
          </span>
        )}
        {deal.isFlashDeal && !expired && (
          <span className="absolute right-2 top-2 rounded-full bg-amber-400 px-2 py-1 text-[10px] font-bold text-amber-950 shadow">
            ⚡ Flash
          </span>
        )}
        <div className="absolute bottom-2 right-2">
          <WishlistButton dealId={deal.id} size="sm" />
        </div>
        {expired && <div className="absolute inset-0 bg-white/50 backdrop-blur-[1px] dark:bg-slate-950/50" />}
      </Link>

      <div className="flex flex-1 flex-col gap-1.5 p-3">
        <p className="text-[10px] font-semibold uppercase tracking-wide text-brand/80">{deal.categoryName}</p>
        <Link href={`/deal/${deal.slug}`} className="line-clamp-2 min-h-[2.5rem] text-sm font-semibold leading-snug text-slate-900 hover:text-brand dark:text-slate-100">
          {deal.productName}
        </Link>

        <div className="mt-1 flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
          <Star size={13} className="fill-amber-400 text-amber-400" />
          <span className="font-medium text-slate-700 dark:text-slate-300">{deal.rating.toFixed(1)}</span>
          <span>· {formatCompactNumber(deal.reviewCount)} reviews</span>
        </div>

        <div className="mt-1.5 flex items-baseline gap-2">
          <span className="text-lg font-extrabold text-slate-900 dark:text-white">{formatBDT(deal.salePrice)}</span>
          {deal.discountPercentage > 0 && (
            <span className="text-xs font-medium text-slate-400 line-through">{formatBDT(deal.regularPrice)}</span>
          )}
        </div>

        {deal.savingsAmount > 0 && (
          <p className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
            🟢 Save {formatBDT(deal.savingsAmount)}
          </p>
        )}

        <div className="mt-auto pt-2">
          <ViewDealButton deal={deal} className="w-full justify-center rounded-xl py-2.5 text-sm" />
        </div>
      </div>
    </div>
  );
}
