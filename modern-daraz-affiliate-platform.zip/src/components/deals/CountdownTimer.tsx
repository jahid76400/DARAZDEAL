"use client";

import { useEffect, useState } from "react";
import clsx from "clsx";

function getRemaining(target: number) {
  const diff = Math.max(0, target - Date.now());
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff / (1000 * 60)) % 60);
  const seconds = Math.floor((diff / 1000) % 60);
  return { diff, hours, minutes, seconds };
}

export default function CountdownTimer({
  endTime,
  compact = false,
  onExpire,
}: {
  endTime: string;
  compact?: boolean;
  onExpire?: () => void;
}) {
  const target = new Date(endTime).getTime();
  const [remaining, setRemaining] = useState(() => getRemaining(target));

  useEffect(() => {
    const interval = setInterval(() => {
      const next = getRemaining(target);
      setRemaining(next);
      if (next.diff <= 0) {
        clearInterval(interval);
        onExpire?.();
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [target, onExpire]);

  if (remaining.diff <= 0) {
    return (
      <span className={clsx("font-semibold text-slate-400", compact ? "text-xs" : "text-sm")}>
        Deal Expired
      </span>
    );
  }

  const pad = (n: number) => n.toString().padStart(2, "0");

  if (compact) {
    return (
      <span className="font-mono text-xs font-semibold tracking-wide text-white">
        {pad(remaining.hours)}h : {pad(remaining.minutes)}m : {pad(remaining.seconds)}s
      </span>
    );
  }

  return (
    <div className="flex items-center gap-1.5 font-mono">
      {[
        { label: "H", value: remaining.hours },
        { label: "M", value: remaining.minutes },
        { label: "S", value: remaining.seconds },
      ].map((unit, idx) => (
        <span key={unit.label} className="flex items-center gap-1.5">
          <span className="flex min-w-[2.4rem] flex-col items-center rounded-xl bg-white/15 px-2.5 py-1.5 text-white backdrop-blur-sm">
            <span className="text-lg font-bold leading-none">{pad(unit.value)}</span>
            <span className="mt-0.5 text-[9px] uppercase tracking-wider text-white/70">{unit.label}</span>
          </span>
          {idx < 2 && <span className="text-white/60">:</span>}
        </span>
      ))}
    </div>
  );
}
