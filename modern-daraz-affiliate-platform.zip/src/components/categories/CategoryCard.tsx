import Link from "next/link";
import * as Icons from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { Category } from "@/lib/types";

export default function CategoryCard({ category, count }: { category: Category; count?: number }) {
  const Icon = (Icons as unknown as Record<string, LucideIcon>)[category.icon] ?? Icons.Sparkles;

  return (
    <Link
      href={`/category/${category.slug}`}
      className="group flex flex-col items-center gap-2.5 rounded-2xl border border-slate-200/70 bg-white p-4 text-center transition-all duration-200 hover:-translate-y-0.5 hover:border-brand/30 hover:shadow-lg dark:border-white/10 dark:bg-slate-900"
    >
      <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-soft text-brand transition-transform duration-200 group-hover:scale-110 dark:bg-brand/15">
        <Icon size={22} strokeWidth={2} />
      </span>
      <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">{category.name}</span>
      {typeof count === "number" && (
        <span className="text-[11px] text-slate-400">{count} deals</span>
      )}
    </Link>
  );
}
