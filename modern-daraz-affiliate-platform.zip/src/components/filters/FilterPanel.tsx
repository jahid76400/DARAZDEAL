"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import clsx from "clsx";
import type { Category } from "@/lib/types";

const PRICE_RANGES = [
  { label: "Under ৳500", min: 0, max: 500 },
  { label: "৳500 – ৳1,000", min: 500, max: 1000 },
  { label: "৳1,000 – ৳5,000", min: 1000, max: 5000 },
  { label: "৳5,000+", min: 5000, max: undefined },
];

const DISCOUNTS = [20, 30, 50, 70];

const SORTS = [
  { value: "discount", label: "Biggest Discount" },
  { value: "price-asc", label: "Lowest Price" },
  { value: "price-desc", label: "Highest Price" },
  { value: "popular", label: "Most Popular" },
  { value: "newest", label: "Newest Deals" },
];

export default function FilterPanel({ categories, hideCategory = false }: { categories: Category[]; hideCategory?: boolean }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [open, setOpen] = useState(false);

  const activeMinPrice = searchParams.get("minPrice");
  const activeMaxPrice = searchParams.get("maxPrice");
  const activeDiscount = searchParams.get("minDiscount");
  const activeCategory = searchParams.get("category");
  const activeSort = searchParams.get("sort") || "discount";

  function updateParam(key: string, value: string | null) {
    const params = new URLSearchParams(searchParams.toString());
    if (value === null) {
      params.delete(key);
    } else {
      params.set(key, value);
    }
    router.push(`${pathname}?${params.toString()}`);
  }

  function setPriceRange(min: number, max: number | undefined) {
    const params = new URLSearchParams(searchParams.toString());
    const isActive = activeMinPrice === String(min) && (activeMaxPrice ?? "") === String(max ?? "");
    if (isActive) {
      params.delete("minPrice");
      params.delete("maxPrice");
    } else {
      params.set("minPrice", String(min));
      if (max !== undefined) params.set("maxPrice", String(max));
      else params.delete("maxPrice");
    }
    router.push(`${pathname}?${params.toString()}`);
  }

  function clearAll() {
    router.push(pathname);
  }

  const hasActiveFilters = Boolean(activeMinPrice || activeMaxPrice || activeDiscount || activeCategory);

  const content = (
    <div className="space-y-6">
      <div>
        <p className="mb-2.5 text-xs font-bold uppercase tracking-wide text-slate-400">Price</p>
        <div className="flex flex-wrap gap-2">
          {PRICE_RANGES.map((range) => {
            const active = activeMinPrice === String(range.min) && (activeMaxPrice ?? "") === String(range.max ?? "");
            return (
              <button
                key={range.label}
                onClick={() => setPriceRange(range.min, range.max)}
                className={clsx(
                  "rounded-full border px-3.5 py-1.5 text-xs font-semibold transition",
                  active
                    ? "border-brand bg-brand text-white"
                    : "border-slate-200 text-slate-600 hover:border-brand/40 hover:text-brand dark:border-white/10 dark:text-slate-300",
                )}
              >
                {range.label}
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <p className="mb-2.5 text-xs font-bold uppercase tracking-wide text-slate-400">Discount</p>
        <div className="flex flex-wrap gap-2">
          {DISCOUNTS.map((d) => {
            const active = activeDiscount === String(d);
            return (
              <button
                key={d}
                onClick={() => updateParam("minDiscount", active ? null : String(d))}
                className={clsx(
                  "rounded-full border px-3.5 py-1.5 text-xs font-semibold transition",
                  active
                    ? "border-brand bg-brand text-white"
                    : "border-slate-200 text-slate-600 hover:border-brand/40 hover:text-brand dark:border-white/10 dark:text-slate-300",
                )}
              >
                {d}%+
              </button>
            );
          })}
        </div>
      </div>

      {!hideCategory && (
        <div>
          <p className="mb-2.5 text-xs font-bold uppercase tracking-wide text-slate-400">Category</p>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => {
              const active = activeCategory === cat.slug;
              return (
                <button
                  key={cat.slug}
                  onClick={() => updateParam("category", active ? null : cat.slug)}
                  className={clsx(
                    "rounded-full border px-3.5 py-1.5 text-xs font-semibold transition",
                    active
                      ? "border-brand bg-brand text-white"
                      : "border-slate-200 text-slate-600 hover:border-brand/40 hover:text-brand dark:border-white/10 dark:text-slate-300",
                  )}
                >
                  {cat.name}
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div>
        <p className="mb-2.5 text-xs font-bold uppercase tracking-wide text-slate-400">Sort By</p>
        <select
          value={activeSort}
          onChange={(e) => updateParam("sort", e.target.value)}
          className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm font-medium text-slate-700 outline-none focus:border-brand dark:border-white/10 dark:bg-slate-800 dark:text-slate-200"
        >
          {SORTS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>
      </div>

      {hasActiveFilters && (
        <button onClick={clearAll} className="text-xs font-semibold text-brand hover:underline">
          Clear all filters
        </button>
      )}
    </div>
  );

  return (
    <>
      <div className="hidden lg:block">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-slate-900">
          <div className="mb-4 flex items-center gap-2 text-sm font-bold text-slate-800 dark:text-slate-100">
            <SlidersHorizontal size={16} /> Filters
          </div>
          {content}
        </div>
      </div>

      <div className="lg:hidden">
        <button
          onClick={() => setOpen(true)}
          className="flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white py-2.5 text-sm font-semibold text-slate-700 dark:border-white/10 dark:bg-slate-900 dark:text-slate-200"
        >
          <SlidersHorizontal size={15} /> Filters & Sort {hasActiveFilters && <span className="h-1.5 w-1.5 rounded-full bg-brand" />}
        </button>

        {open && (
          <div className="fixed inset-0 z-[60] flex items-end bg-black/40" onClick={() => setOpen(false)}>
            <div
              onClick={(e) => e.stopPropagation()}
              className="max-h-[80vh] w-full overflow-y-auto rounded-t-3xl bg-white p-5 pb-8 dark:bg-slate-900"
            >
              <div className="mb-4 flex items-center justify-between">
                <p className="text-base font-bold text-slate-900 dark:text-white">Filters & Sort</p>
                <button onClick={() => setOpen(false)} aria-label="Close">
                  <X size={20} />
                </button>
              </div>
              {content}
              <button
                onClick={() => setOpen(false)}
                className="mt-6 w-full rounded-full bg-brand py-3 text-sm font-bold text-white"
              >
                Show results
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
