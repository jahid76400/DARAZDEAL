"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { computePricing } from "@/lib/pricing";
import { formatBDT } from "@/lib/format";
import type { Category, Deal } from "@/lib/types";

type FormState = {
  productName: string;
  slug: string;
  productImage: string;
  categoryId: string;
  brand: string;
  regularPrice: string;
  salePrice: string;
  rating: string;
  reviewCount: string;
  affiliateUrl: string;
  description: string;
  dealEnd: string;
  status: "active" | "expired" | "draft";
  featured: boolean;
  isFlashDeal: boolean;
};

function toFormState(deal?: Deal | null): FormState {
  return {
    productName: deal?.productName ?? "",
    slug: deal?.slug ?? "",
    productImage: deal?.productImage ?? "",
    categoryId: deal ? String(deal.categoryId) : "",
    brand: deal?.brand ?? "",
    regularPrice: deal ? String(deal.regularPrice) : "",
    salePrice: deal ? String(deal.salePrice) : "",
    rating: deal ? String(deal.rating) : "4.5",
    reviewCount: deal ? String(deal.reviewCount) : "0",
    affiliateUrl: deal?.affiliateUrl ?? "https://www.daraz.com.bd/products/example-i000000000-s0000000000.html?spm=affiliate",
    description: deal?.description ?? "",
    dealEnd: deal?.dealEnd ? deal.dealEnd.slice(0, 16) : "",
    status: deal?.status ?? "active",
    featured: deal?.featured ?? false,
    isFlashDeal: deal?.isFlashDeal ?? false,
  };
}

export default function AdminDealForm({ categories, deal }: { categories: Category[]; deal?: Deal | null }) {
  const router = useRouter();
  const [form, setForm] = useState<FormState>(() => toFormState(deal));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const pricing = useMemo(
    () =>
      computePricing({
        regularPrice: Number(form.regularPrice) || 0,
        salePrice: Number(form.salePrice) || 0,
      }),
    [form.regularPrice, form.salePrice],
  );

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");

    const payload = {
      ...form,
      categoryId: Number(form.categoryId),
      regularPrice: Number(form.regularPrice),
      salePrice: Number(form.salePrice),
      rating: Number(form.rating),
      reviewCount: Number(form.reviewCount),
      dealEnd: form.dealEnd || null,
    };

    try {
      const res = await fetch(deal ? `/api/admin/deals/${deal.id}` : "/api/admin/deals", {
        method: deal ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error ?? "Something went wrong");
        return;
      }
      router.push("/admin");
      router.refresh();
    } finally {
      setSaving(false);
    }
  }

  const inputClass =
    "w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm outline-none focus:border-brand focus:bg-white focus:ring-2 focus:ring-brand/20 dark:border-white/10 dark:bg-slate-800 dark:text-white";
  const labelClass = "mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400";

  return (
    <form onSubmit={handleSubmit} className="grid gap-6 lg:grid-cols-[1fr_320px]">
      <div className="space-y-5 rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-slate-900">
        <div>
          <label className={labelClass}>Product Name</label>
          <input required value={form.productName} onChange={(e) => update("productName", e.target.value)} className={inputClass} />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className={labelClass}>Slug (optional)</label>
            <input value={form.slug} onChange={(e) => update("slug", e.target.value)} placeholder="auto-generated if empty" className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>Brand</label>
            <input value={form.brand} onChange={(e) => update("brand", e.target.value)} className={inputClass} />
          </div>
        </div>

        <div>
          <label className={labelClass}>Product Image URL</label>
          <input required value={form.productImage} onChange={(e) => update("productImage", e.target.value)} className={inputClass} />
        </div>

        <div>
          <label className={labelClass}>Category</label>
          <select required value={form.categoryId} onChange={(e) => update("categoryId", e.target.value)} className={inputClass}>
            <option value="">Select a category</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className={labelClass}>Regular Price (৳)</label>
            <input required type="number" min={0} step="0.01" value={form.regularPrice} onChange={(e) => update("regularPrice", e.target.value)} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>Sale Price (৳)</label>
            <input required type="number" min={0} step="0.01" value={form.salePrice} onChange={(e) => update("salePrice", e.target.value)} className={inputClass} />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className={labelClass}>Rating (0–5)</label>
            <input type="number" min={0} max={5} step="0.1" value={form.rating} onChange={(e) => update("rating", e.target.value)} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>Review Count</label>
            <input type="number" min={0} value={form.reviewCount} onChange={(e) => update("reviewCount", e.target.value)} className={inputClass} />
          </div>
        </div>

        <div>
          <label className={labelClass}>Daraz Affiliate URL</label>
          <input required value={form.affiliateUrl} onChange={(e) => update("affiliateUrl", e.target.value)} className={inputClass} />
        </div>

        <div>
          <label className={labelClass}>Description</label>
          <textarea rows={4} value={form.description} onChange={(e) => update("description", e.target.value)} className={inputClass} />
        </div>

        {error && <p className="text-xs font-semibold text-red-500">{error}</p>}
      </div>

      <div className="space-y-5">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-slate-900">
          <p className="mb-3 text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Live Preview</p>
          <div className="rounded-xl bg-slate-50 p-4 dark:bg-slate-800">
            <p className="text-lg font-extrabold text-slate-900 dark:text-white">{formatBDT(Number(form.salePrice) || 0)}</p>
            {pricing.hasDiscount && (
              <>
                <p className="text-xs text-slate-400 line-through">{formatBDT(Number(form.regularPrice) || 0)}</p>
                <p className="mt-1 text-sm font-bold text-emerald-600">
                  Save {formatBDT(pricing.savingsAmount)} · {pricing.discountPercentage}% OFF
                </p>
              </>
            )}
            {!pricing.hasDiscount && <p className="mt-1 text-xs text-slate-400">No discount (sale ≥ regular price)</p>}
          </div>
        </div>

        <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-slate-900">
          <div>
            <label className={labelClass}>Status</label>
            <select value={form.status} onChange={(e) => update("status", e.target.value as FormState["status"])} className={inputClass}>
              <option value="active">Active</option>
              <option value="draft">Draft</option>
              <option value="expired">Expired</option>
            </select>
          </div>

          <div>
            <label className={labelClass}>Deal Expiration (optional)</label>
            <input type="datetime-local" value={form.dealEnd} onChange={(e) => update("dealEnd", e.target.value)} className={inputClass} />
          </div>

          <label className="flex items-center justify-between rounded-xl bg-slate-50 px-3.5 py-2.5 text-sm font-medium text-slate-700 dark:bg-slate-800 dark:text-slate-200">
            Featured deal
            <input type="checkbox" checked={form.featured} onChange={(e) => update("featured", e.target.checked)} className="h-4 w-4 accent-brand" />
          </label>

          <label className="flex items-center justify-between rounded-xl bg-slate-50 px-3.5 py-2.5 text-sm font-medium text-slate-700 dark:bg-slate-800 dark:text-slate-200">
            Flash deal
            <input type="checkbox" checked={form.isFlashDeal} onChange={(e) => update("isFlashDeal", e.target.checked)} className="h-4 w-4 accent-brand" />
          </label>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="w-full rounded-xl bg-brand py-3 text-sm font-bold text-white transition hover:bg-brand-dark disabled:opacity-60"
        >
          {saving ? "Saving…" : deal ? "Save Changes" : "Create Deal"}
        </button>
      </div>
    </form>
  );
}
