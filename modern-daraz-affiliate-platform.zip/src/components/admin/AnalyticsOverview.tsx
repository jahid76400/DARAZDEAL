import { Eye, MousePointerClick, Percent, Package } from "lucide-react";
import type { Deal } from "@/lib/types";

type Overview = {
  totals: { totalViews: number; totalClicks: number; totalDeals: number; activeDeals: number; ctr: number };
  topViewed: Deal[];
  topClicked: Deal[];
  categoryStats: { categoryName: string | null; views: number; clicks: number; dealCount: number }[];
};

export default function AnalyticsOverview({ overview }: { overview: Overview }) {
  const { totals, topViewed, topClicked, categoryStats } = overview;

  const cards = [
    { label: "Total Views", value: totals.totalViews.toLocaleString(), icon: Eye, color: "bg-sky-100 text-sky-600 dark:bg-sky-500/10" },
    { label: "Total Clicks", value: totals.totalClicks.toLocaleString(), icon: MousePointerClick, color: "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/10" },
    { label: "Affiliate CTR", value: `${totals.ctr.toFixed(1)}%`, icon: Percent, color: "bg-amber-100 text-amber-600 dark:bg-amber-500/10" },
    { label: "Active Deals", value: `${totals.activeDeals} / ${totals.totalDeals}`, icon: Package, color: "bg-brand-soft text-brand dark:bg-brand/15" },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {cards.map((card) => (
          <div key={card.label} className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-slate-900">
            <span className={`flex h-9 w-9 items-center justify-center rounded-lg ${card.color}`}>
              <card.icon size={17} />
            </span>
            <p className="mt-3 text-xl font-extrabold text-slate-900 dark:text-white">{card.value}</p>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{card.label}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-slate-900">
          <p className="mb-3 text-sm font-bold text-slate-800 dark:text-slate-100">Most Viewed Deals</p>
          <ul className="space-y-2.5">
            {topViewed.slice(0, 6).map((deal) => (
              <li key={deal.id} className="flex items-center justify-between gap-3 text-sm">
                <span className="line-clamp-1 text-slate-600 dark:text-slate-300">{deal.productName}</span>
                <span className="shrink-0 font-bold text-slate-900 dark:text-white">{deal.viewCount} views</span>
              </li>
            ))}
            {topViewed.length === 0 && <p className="text-xs text-slate-400">No view data yet.</p>}
          </ul>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-slate-900">
          <p className="mb-3 text-sm font-bold text-slate-800 dark:text-slate-100">Top Performing Deals (Clicks)</p>
          <ul className="space-y-2.5">
            {topClicked.slice(0, 6).map((deal) => (
              <li key={deal.id} className="flex items-center justify-between gap-3 text-sm">
                <span className="line-clamp-1 text-slate-600 dark:text-slate-300">{deal.productName}</span>
                <span className="shrink-0 font-bold text-slate-900 dark:text-white">{deal.clickCount} clicks</span>
              </li>
            ))}
            {topClicked.length === 0 && <p className="text-xs text-slate-400">No click data yet.</p>}
          </ul>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-slate-900">
        <p className="mb-3 text-sm font-bold text-slate-800 dark:text-slate-100">Best Performing Categories</p>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[480px] text-left text-sm">
            <thead>
              <tr className="text-xs uppercase text-slate-400">
                <th className="pb-2">Category</th>
                <th className="pb-2">Deals</th>
                <th className="pb-2">Views</th>
                <th className="pb-2">Clicks</th>
                <th className="pb-2">CTR</th>
              </tr>
            </thead>
            <tbody>
              {categoryStats.map((cat) => (
                <tr key={cat.categoryName} className="border-t border-slate-100 dark:border-white/5">
                  <td className="py-2 font-medium text-slate-700 dark:text-slate-200">{cat.categoryName}</td>
                  <td className="py-2 text-slate-500">{cat.dealCount}</td>
                  <td className="py-2 text-slate-500">{cat.views}</td>
                  <td className="py-2 text-slate-500">{cat.clicks}</td>
                  <td className="py-2 font-semibold text-slate-700 dark:text-slate-200">
                    {cat.views > 0 ? `${((cat.clicks / cat.views) * 100).toFixed(1)}%` : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
