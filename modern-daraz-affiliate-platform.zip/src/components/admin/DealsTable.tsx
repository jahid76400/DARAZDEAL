"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Pencil, Trash2, Star, Zap } from "lucide-react";
import clsx from "clsx";
import { formatBDT } from "@/lib/format";
import type { Deal } from "@/lib/types";

export default function DealsTable({ deals }: { deals: Deal[] }) {
  const router = useRouter();
  const [pendingId, setPendingId] = useState<number | null>(null);

  async function handleDelete(id: number) {
    if (!confirm("Delete this deal permanently?")) return;
    setPendingId(id);
    try {
      await fetch(`/api/admin/deals/${id}`, { method: "DELETE" });
      router.refresh();
    } finally {
      setPendingId(null);
    }
  }

  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white dark:border-white/10 dark:bg-slate-900">
      <table className="w-full min-w-[920px] text-left text-sm">
        <thead className="bg-slate-50 text-xs uppercase text-slate-400 dark:bg-slate-800/50">
          <tr>
            <th className="px-4 py-3">Product</th>
            <th className="px-4 py-3">Category</th>
            <th className="px-4 py-3">Price</th>
            <th className="px-4 py-3">Discount</th>
            <th className="px-4 py-3">Status</th>
            <th className="px-4 py-3">Views / Clicks</th>
            <th className="px-4 py-3 text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
          {deals.map((deal) => (
            <tr key={deal.id} className="border-t border-slate-100 dark:border-white/5">
              <td className="max-w-[240px] px-4 py-3">
                <div className="flex items-center gap-2">
                  <p className="line-clamp-1 font-semibold text-slate-800 dark:text-slate-100">{deal.productName}</p>
                  {deal.featured && <Star size={13} className="shrink-0 fill-amber-400 text-amber-400" />}
                  {deal.isFlashDeal && <Zap size={13} className="shrink-0 fill-brand text-brand" />}
                </div>
                <p className="text-xs text-slate-400">{deal.brand}</p>
              </td>
              <td className="px-4 py-3 text-slate-500">{deal.categoryName}</td>
              <td className="px-4 py-3">
                <p className="font-semibold text-slate-800 dark:text-slate-100">{formatBDT(deal.salePrice)}</p>
                <p className="text-xs text-slate-400 line-through">{formatBDT(deal.regularPrice)}</p>
              </td>
              <td className="px-4 py-3 font-bold text-emerald-600 dark:text-emerald-400">
                {deal.discountPercentage > 0 ? `${deal.discountPercentage}%` : "—"}
              </td>
              <td className="px-4 py-3">
                <span
                  className={clsx(
                    "rounded-full px-2.5 py-1 text-xs font-semibold capitalize",
                    deal.isExpired
                      ? "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400"
                      : deal.status === "active"
                        ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400"
                        : "bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400",
                  )}
                >
                  {deal.isExpired ? "expired" : deal.status}
                </span>
              </td>
              <td className="px-4 py-3 text-slate-500">{deal.viewCount} / {deal.clickCount}</td>
              <td className="px-4 py-3">
                <div className="flex items-center justify-end gap-2">
                  <Link
                    href={`/admin/deals/${deal.id}/edit`}
                    className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-500 hover:border-brand/40 hover:text-brand dark:border-white/10"
                  >
                    <Pencil size={14} />
                  </Link>
                  <button
                    onClick={() => handleDelete(deal.id)}
                    disabled={pendingId === deal.id}
                    className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-500 hover:border-red-300 hover:text-red-500 disabled:opacity-50 dark:border-white/10"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
          {deals.length === 0 && (
            <tr>
              <td colSpan={7} className="px-4 py-10 text-center text-sm text-slate-400">
                No deals yet. Click &quot;Add Deal&quot; to create your first one.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
