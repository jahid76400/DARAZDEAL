import Link from "next/link";
import { ArrowRight, TrendingDown, ShieldCheck, Zap } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-orange-50 via-white to-transparent dark:from-slate-900 dark:via-slate-950">
      <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-brand/20 blur-3xl" />
      <div className="pointer-events-none absolute -right-20 top-20 h-64 w-64 rounded-full bg-amber-300/30 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-4 py-14 text-center sm:px-6 sm:py-20">
        <span className="animate-fade-in-up mx-auto inline-flex items-center gap-1.5 rounded-full border border-brand/20 bg-brand-soft px-3.5 py-1.5 text-xs font-semibold text-brand dark:border-brand/30 dark:bg-brand/10">
          <Zap size={13} /> Updated daily with verified Daraz discounts
        </span>

        <h1 className="animate-fade-in-up mx-auto mt-5 max-w-3xl text-[clamp(2rem,6vw,3.5rem)] font-extrabold leading-[1.08] tracking-tight text-slate-900 [animation-delay:80ms] dark:text-white">
          Find the Best <span className="text-brand">Daraz Deals</span> in One Place
        </h1>

        <p className="animate-fade-in-up mx-auto mt-4 max-w-xl text-base text-slate-600 [animation-delay:160ms] sm:text-lg dark:text-slate-300">
          Discover today&apos;s biggest discounts, compare prices, and save more on your next Daraz purchase.
        </p>

        <div className="animate-fade-in-up mt-8 flex flex-col items-center justify-center gap-3 [animation-delay:240ms] sm:flex-row">
          <Link
            href="/deals/today"
            className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-brand px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-brand/30 transition hover:-translate-y-0.5 hover:bg-brand-dark sm:w-auto"
          >
            Explore Today&apos;s Deals <ArrowRight size={16} />
          </Link>
          <Link
            href="/deals/biggest-discounts"
            className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-7 py-3.5 text-sm font-bold text-slate-800 transition hover:-translate-y-0.5 hover:border-brand/40 hover:text-brand sm:w-auto dark:border-white/15 dark:bg-slate-900 dark:text-slate-100"
          >
            <TrendingDown size={16} /> Biggest Discounts
          </Link>
        </div>

        <div className="animate-fade-in-up mx-auto mt-10 flex max-w-xl flex-wrap items-center justify-center gap-x-8 gap-y-3 text-xs font-medium text-slate-500 [animation-delay:320ms] dark:text-slate-400">
          <span className="flex items-center gap-1.5"><ShieldCheck size={15} className="text-emerald-500" /> No fake discounts</span>
          <span className="flex items-center gap-1.5"><TrendingDown size={15} className="text-brand" /> Real price comparisons</span>
          <span className="flex items-center gap-1.5"><Zap size={15} className="text-amber-500" /> Daily flash deals</span>
        </div>
      </div>
    </section>
  );
}
