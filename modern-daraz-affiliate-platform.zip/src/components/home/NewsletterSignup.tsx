"use client";

import { useState } from "react";
import { Bell } from "lucide-react";

export default function NewsletterSignup() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email) return;
    setStatus("loading");
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error("failed");
      setStatus("done");
      setEmail("");
    } catch {
      setStatus("error");
    }
  }

  return (
    <div className="flex flex-col items-center gap-4 text-center text-white sm:flex-row sm:text-left">
      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/20">
        <Bell size={22} />
      </span>
      <div className="flex-1">
        <h3 className="text-lg font-bold">Get notified when your favorite deals drop</h3>
        <p className="mt-1 text-sm text-white/85">
          🔔 Subscribe for deal alerts by email. Telegram, WhatsApp & push notifications coming soon.
        </p>
      </div>
      <form onSubmit={handleSubmit} className="flex w-full max-w-sm shrink-0 gap-2 sm:w-auto">
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@email.com"
          className="w-full rounded-full border-0 bg-white/95 px-4 py-2.5 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:ring-2 focus:ring-white"
        />
        <button
          type="submit"
          disabled={status === "loading"}
          className="shrink-0 rounded-full bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800 disabled:opacity-60"
        >
          {status === "done" ? "Subscribed ✓" : "Notify Me"}
        </button>
      </form>
    </div>
  );
}
