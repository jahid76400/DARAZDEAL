"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Zap, TrendingDown, Heart, Search } from "lucide-react";
import clsx from "clsx";

const ITEMS = [
  { href: "/", label: "Home", icon: Home },
  { href: "/deals/flash", label: "Flash", icon: Zap },
  { href: "/search", label: "Search", icon: Search },
  { href: "/deals/biggest-discounts", label: "Top %", icon: TrendingDown },
  { href: "/wishlist", label: "Saved", icon: Heart },
];

export default function MobileBottomNav() {
  const pathname = usePathname();

  if (pathname?.startsWith("/admin")) return null;

  return (
    <nav className="fixed inset-x-0 bottom-0 z-50 grid grid-cols-5 border-t border-slate-200 bg-white/95 backdrop-blur-lg md:hidden dark:border-white/10 dark:bg-slate-950/95">
      {ITEMS.map((item) => {
        const active = item.href === "/" ? pathname === "/" : pathname?.startsWith(item.href);
        const Icon = item.icon;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={clsx(
              "flex flex-col items-center justify-center gap-0.5 py-2.5 text-[10px] font-medium transition-colors",
              active ? "text-brand" : "text-slate-500 dark:text-slate-400",
            )}
          >
            <Icon size={19} strokeWidth={active ? 2.5 : 2} />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
