import Link from "next/link";
import { Sparkles } from "lucide-react";
import type { Category } from "@/lib/types";
import NewsletterSignup from "@/components/home/NewsletterSignup";

export default function Footer({ categories }: { categories: Category[] }) {
  return (
    <footer className="mt-16 border-t border-slate-200 bg-white dark:border-white/10 dark:bg-slate-950">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="rounded-3xl bg-gradient-to-br from-brand to-orange-500 p-8 sm:p-10">
          <NewsletterSignup />
        </div>

        <div className="mt-12 grid grid-cols-2 gap-8 sm:grid-cols-4">
          <div className="col-span-2">
            <Link href="/" className="flex items-center gap-1.5 text-lg font-extrabold text-slate-900 dark:text-white">
              <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-brand text-white">
                <Sparkles size={17} />
              </span>
              Deal<span className="text-brand">Bazi</span>
            </Link>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-slate-500 dark:text-slate-400">
              A premium destination for discovering the best Daraz deals in Bangladesh. We compare prices
              daily so you always know exactly how much you save.
            </p>
            <p className="mt-4 max-w-sm text-xs leading-relaxed text-slate-400 dark:text-slate-500">
              ⚠️ Prices and availability may change on Daraz. Please verify the final price before purchasing.
              As an affiliate, DealBazi may earn a commission on qualifying purchases.
            </p>
          </div>

          <div>
            <p className="text-xs font-bold uppercase tracking-wide text-slate-900 dark:text-white">Explore</p>
            <ul className="mt-3 space-y-2 text-sm text-slate-500 dark:text-slate-400">
              <li><Link href="/deals/today" className="hover:text-brand">Today&apos;s Deals</Link></li>
              <li><Link href="/deals/flash" className="hover:text-brand">Flash Deals</Link></li>
              <li><Link href="/deals/biggest-discounts" className="hover:text-brand">Biggest Discounts</Link></li>
              <li><Link href="/deals/under/500" className="hover:text-brand">Under ৳500</Link></li>
              <li><Link href="/wishlist" className="hover:text-brand">My Wishlist</Link></li>
            </ul>
          </div>

          <div>
            <p className="text-xs font-bold uppercase tracking-wide text-slate-900 dark:text-white">Categories</p>
            <ul className="mt-3 space-y-2 text-sm text-slate-500 dark:text-slate-400">
              {categories.slice(0, 5).map((cat) => (
                <li key={cat.slug}>
                  <Link href={`/category/${cat.slug}`} className="hover:text-brand">{cat.name}</Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-slate-100 pt-6 text-xs text-slate-400 sm:flex-row dark:border-white/10">
          <p>© {new Date().getFullYear()} DealBazi. Not affiliated with Daraz. Independent deal discovery platform.</p>
          <Link href="/admin" className="hover:text-brand">Admin</Link>
        </div>
      </div>
    </footer>
  );
}
