"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, Sparkles, X, Heart } from "lucide-react";
import ThemeToggle from "@/components/theme/ThemeToggle";
import SearchBar from "@/components/search/SearchBar";
import type { Category } from "@/lib/types";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/deals/today", label: "Today's Deals" },
  { href: "/deals/flash", label: "Flash Deals" },
  { href: "/deals/biggest-discounts", label: "Biggest Discounts" },
  { href: "/deals/under/500", label: "Under ৳500" },
];

export default function Header({ categories }: { categories: Category[] }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileSearch, setMobileSearch] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/70 bg-white/85 backdrop-blur-lg dark:border-white/10 dark:bg-slate-950/85">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6">
        <Link href="/" className="flex shrink-0 items-center gap-1.5 text-lg font-extrabold tracking-tight text-slate-900 dark:text-white">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-brand text-white">
            <Sparkles size={17} />
          </span>
          Deal<span className="text-brand">Bazi</span>
        </Link>

        <nav className="hidden flex-1 items-center gap-1 lg:flex">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-full px-3 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
            >
              {link.label}
            </Link>
          ))}
          <div className="group relative">
            <button className="rounded-full px-3 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white">
              Categories
            </button>
            <div className="invisible absolute left-0 top-full grid w-[520px] grid-cols-2 gap-1 rounded-2xl border border-slate-200 bg-white p-3 opacity-0 shadow-xl transition-all duration-150 group-hover:visible group-hover:opacity-100 dark:border-white/10 dark:bg-slate-900">
              {categories.map((cat) => (
                <Link
                  key={cat.slug}
                  href={`/category/${cat.slug}`}
                  className="rounded-lg px-3 py-2 text-sm text-slate-600 hover:bg-brand-soft hover:text-brand dark:text-slate-300 dark:hover:bg-brand/10"
                >
                  {cat.name}
                </Link>
              ))}
            </div>
          </div>
        </nav>

        <div className="hidden flex-1 max-w-sm md:block lg:max-w-xs">
          <SearchBar size="sm" />
        </div>

        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={() => setMobileSearch((v) => !v)}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-600 md:hidden dark:border-white/10 dark:text-slate-300"
            aria-label="Search"
          >
            {mobileSearch ? <X size={17} /> : <Sparkles size={17} className="opacity-0" />}
          </button>
          <Link
            href="/wishlist"
            className="hidden h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-600 transition-colors hover:border-brand/40 hover:text-brand sm:flex dark:border-white/10 dark:text-slate-300"
            aria-label="Wishlist"
          >
            <Heart size={17} />
          </Link>
          <ThemeToggle className="hidden sm:flex" />
          <button
            onClick={() => setMobileOpen((v) => !v)}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-600 lg:hidden dark:border-white/10 dark:text-slate-300"
            aria-label="Menu"
          >
            {mobileOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {mobileSearch && (
        <div className="border-t border-slate-100 px-4 py-3 md:hidden dark:border-white/10">
          <SearchBar autoFocus size="sm" onSubmitted={() => setMobileSearch(false)} />
        </div>
      )}

      {mobileOpen && (
        <nav className="flex flex-col gap-1 border-t border-slate-100 px-4 py-3 lg:hidden dark:border-white/10">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              className="rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              {link.label}
            </Link>
          ))}
          <p className="mt-2 px-3 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Categories</p>
          <div className="grid grid-cols-2 gap-1">
            {categories.map((cat) => (
              <Link
                key={cat.slug}
                href={`/category/${cat.slug}`}
                onClick={() => setMobileOpen(false)}
                className="rounded-xl px-3 py-2 text-sm text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                {cat.name}
              </Link>
            ))}
          </div>
          <div className="mt-2 flex items-center justify-between px-3">
            <Link href="/wishlist" onClick={() => setMobileOpen(false)} className="flex items-center gap-1.5 text-sm font-medium text-slate-600 dark:text-slate-300">
              <Heart size={16} /> Wishlist
            </Link>
            <ThemeToggle />
          </div>
        </nav>
      )}
    </header>
  );
}
