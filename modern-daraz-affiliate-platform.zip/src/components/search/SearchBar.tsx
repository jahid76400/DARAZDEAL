"use client";

import { Search, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import clsx from "clsx";

type Suggestion = { slug: string; productName: string; categoryName: string };

export default function SearchBar({
  autoFocus = false,
  placeholder = "Search earbuds, watches, brands...",
  initialValue = "",
  size = "md",
  onSubmitted,
}: {
  autoFocus?: boolean;
  placeholder?: string;
  initialValue?: string;
  size?: "sm" | "md" | "lg";
  onSubmitted?: () => void;
}) {
  const router = useRouter();
  const [value, setValue] = useState(initialValue);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (!value || value.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    const controller = new AbortController();
    const timeout = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search/suggestions?q=${encodeURIComponent(value)}`, {
          signal: controller.signal,
        });
        if (res.ok) {
          const data = await res.json();
          setSuggestions(data.results ?? []);
          setOpen(true);
        }
      } catch {
        // ignore aborted/failed requests
      }
    }, 220);
    return () => {
      clearTimeout(timeout);
      controller.abort();
    };
  }, [value]);

  function submit(query: string) {
    const q = query.trim();
    if (!q) return;
    router.push(`/search?q=${encodeURIComponent(q)}`);
    setOpen(false);
    onSubmitted?.();
  }

  const sizeClasses =
    size === "lg" ? "h-14 pl-13 pr-14 text-base" : size === "sm" ? "h-10 pl-10 pr-9 text-sm" : "h-11 pl-11 pr-10 text-sm";

  return (
    <div ref={containerRef} className="relative w-full">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(value);
        }}
        className="relative"
      >
        <Search
          size={size === "lg" ? 20 : 16}
          className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
        />
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onFocus={() => value.length >= 2 && setOpen(true)}
          autoFocus={autoFocus}
          placeholder={placeholder}
          className={clsx(
            "w-full rounded-full border border-slate-200 bg-slate-50 text-slate-900 placeholder:text-slate-400 outline-none transition focus:border-brand focus:bg-white focus:ring-2 focus:ring-brand/20 dark:border-white/10 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-800",
            sizeClasses,
          )}
        />
        {value && (
          <button
            type="button"
            onClick={() => {
              setValue("");
              setSuggestions([]);
            }}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
          >
            <X size={16} />
          </button>
        )}
      </form>

      {open && suggestions.length > 0 && (
        <div className="absolute z-40 mt-2 w-full overflow-hidden rounded-2xl border border-slate-200 bg-white py-2 shadow-xl dark:border-white/10 dark:bg-slate-900">
          {suggestions.map((s) => (
            <button
              key={s.slug}
              onClick={() => submit(s.productName)}
              className="flex w-full items-center justify-between px-4 py-2.5 text-left text-sm hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              <span className="font-medium text-slate-800 dark:text-slate-100">{s.productName}</span>
              <span className="text-xs text-slate-400">{s.categoryName}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
